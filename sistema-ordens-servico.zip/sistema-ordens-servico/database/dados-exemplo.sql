-- =====================================================================
-- TecOS - Dados de exemplo para demonstracao
-- ATENCAO: apaga os clientes, equipamentos e ordens existentes!
-- Execute depois do schema.sql. As datas sao relativas ao dia de hoje.
-- =====================================================================

SET NAMES utf8mb4;
USE assistencia_os;

DELETE FROM historico_status;
DELETE FROM ordem_servico;
DELETE FROM equipamento;
DELETE FROM cliente;

INSERT INTO cliente (id, nome, cpf, telefone, email, endereco, data_cadastro) VALUES
    (1, 'Mariana Souza Lima', '52601815906', '11987654321', 'mariana.lima@exemplo.com', 'Rua das Figueiras, 120 - Santo André', NOW() - INTERVAL 60 DAY),
    (2, 'Carlos Eduardo Pereira', '08301661305', '11976543210', 'carlos.pereira@exemplo.com', 'Av. Industrial, 455 - Santo André', NOW() - INTERVAL 56 DAY),
    (3, 'Ana Beatriz Rocha', '18609139034', '11965432109', NULL, 'Rua Coronel Oliveira Lima, 88 - Santo André', NOW() - INTERVAL 52 DAY),
    (4, 'João Victor Almeida', '99603082430', '11954321098', 'joao.almeida@exemplo.com', NULL, NOW() - INTERVAL 48 DAY),
    (5, 'Fernanda Oliveira Santos', '62819482112', '11943210987', 'fernanda.santos@exemplo.com', 'Rua Goiás, 310 - São Caetano do Sul', NOW() - INTERVAL 44 DAY),
    (6, 'Rafael Costa Martins', '99351819019', '1144556677', NULL, 'Av. Kennedy, 1500 - São Bernardo do Campo', NOW() - INTERVAL 40 DAY),
    (7, 'Juliana Ferreira Gomes', '93786579741', '11932109876', 'juliana.gomes@exemplo.com', NULL, NOW() - INTERVAL 36 DAY),
    (8, 'Lucas Henrique Barbosa', '54323194897', '11921098765', NULL, 'Rua Senador Flaquer, 72 - Santo André', NOW() - INTERVAL 32 DAY),
    (9, 'Patrícia Ribeiro Dias', '75749118606', '11910987654', 'patricia.dias@exemplo.com', NULL, NOW() - INTERVAL 28 DAY),
    (10, 'Escritório Contábil Alfa', NULL, '1143218765', 'contato@contabilalfa.exemplo.com', 'Rua Bernardino de Campos, 200 - Santo André', NOW() - INTERVAL 24 DAY);

INSERT INTO equipamento (id, cliente_id, tipo, marca, modelo, numero_serie, observacoes) VALUES
    (1, 1, 'NOTEBOOK', 'Dell', 'Inspiron 15 3520', '7HX2K93', 'Acompanha carregador'),
    (2, 2, 'DESKTOP', 'Montado', 'Ryzen 5 5600 / B550 / RTX 3060', NULL, 'Gabinete com vidro lateral'),
    (3, 3, 'CELULAR', 'Samsung', 'Galaxy A54', 'R5CT20ABC1X', NULL),
    (4, 4, 'VIDEOGAME', 'Sony', 'PlayStation 4 Slim', 'MB012345678', 'Sem controle'),
    (5, 5, 'NOTEBOOK', 'Lenovo', 'IdeaPad 3 15ITL6', 'PF3K8Z2M', NULL),
    (6, 6, 'IMPRESSORA', 'HP', 'DeskJet 2774', 'CN12B3C4D5', NULL),
    (7, 7, 'NOTEBOOK', 'Acer', 'Aspire 5 A515-54', 'NXHN1AL001', 'Tela com pequeno risco'),
    (8, 8, 'DESKTOP', 'Positivo', 'Master D3400', NULL, NULL),
    (9, 9, 'MONITOR', 'LG', '24MK430H', '908NTQD1A234', NULL),
    (10, 10, 'DESKTOP', 'Dell', 'OptiPlex 3080', '5JQ8M53', 'Computador da recepção'),
    (11, 10, 'NOTEBOOK', 'HP', '250 G8', '5CD1234XYZ', NULL),
    (12, 1, 'TABLET', 'Samsung', 'Galaxy Tab A8', 'R9WT30DEF2Y', 'Capa azul');

INSERT INTO ordem_servico (id, equipamento_id, tecnico_id, defeito_relatado, diagnostico, servico_executado,
                           status, valor_orcamento, data_abertura, data_previsao, data_conclusao, data_entrega) VALUES
    (1, 1, 1, 'Notebook não liga, nem acende a luz de carga.', 'Conector DC de alimentação danificado na placa-mãe.', 'Substituição do conector DC e teste de carga.',
     'ENTREGUE', 180.00, CURDATE() - INTERVAL 9 DAY + INTERVAL 660 MINUTE, CURDATE() - INTERVAL 5 DAY, CURDATE() - INTERVAL 5 DAY + INTERVAL 780 MINUTE, CURDATE() - INTERVAL 4 DAY + INTERVAL 600 MINUTE),
    (2, 2, 1, 'Computador reinicia sozinho durante jogos.', 'Fonte genérica de 450 W não suporta a placa de vídeo.', 'Troca da fonte por modelo de 550 W 80 Plus Bronze e limpeza interna.',
     'ENTREGUE', 350.00, CURDATE() - INTERVAL 8 DAY + INTERVAL 780 MINUTE, CURDATE() - INTERVAL 3 DAY, CURDATE() - INTERVAL 3 DAY + INTERVAL 900 MINUTE, CURDATE() - INTERVAL 2 DAY + INTERVAL 720 MINUTE),
    (3, 3, 1, 'Tela trincada após queda; o touch funciona só em parte.', 'Display AMOLED quebrado.', 'Troca do conjunto frontal (display + touch).',
     'PRONTA', 420.00, CURDATE() - INTERVAL 6 DAY + INTERVAL 900 MINUTE, CURDATE() + INTERVAL 0 DAY, CURDATE() - INTERVAL 1 DAY + INTERVAL 600 MINUTE, NULL),
    (4, 4, 1, 'Console superaquece e desliga depois de 20 minutos de uso.', 'Pasta térmica ressecada e cooler com acúmulo de poeira.', NULL,
     'EM_REPARO', 250.00, CURDATE() - INTERVAL 4 DAY + INTERVAL 600 MINUTE, CURDATE() + INTERVAL 1 DAY, NULL, NULL),
    (5, 5, 1, 'Várias teclas do teclado não funcionam.', 'Teclado com oxidação por líquido; é necessária a troca.', NULL,
     'AGUARDANDO_PECA', 390.00, CURDATE() - INTERVAL 7 DAY + INTERVAL 720 MINUTE, CURDATE() - INTERVAL 1 DAY, NULL, NULL),
    (6, 6, 1, 'Impressora não puxa o papel.', 'Roletes de tração gastos.', NULL,
     'AGUARDANDO_APROVACAO', 160.00, CURDATE() - INTERVAL 3 DAY + INTERVAL 840 MINUTE, CURDATE() + INTERVAL 3 DAY, NULL, NULL),
    (7, 7, 1, 'Notebook muito lento, trava ao abrir programas.', NULL, NULL,
     'EM_ANALISE', NULL, CURDATE() - INTERVAL 2 DAY + INTERVAL 540 MINUTE, CURDATE() + INTERVAL 2 DAY, NULL, NULL),
    (8, 8, 1, 'Computador liga, mas não dá vídeo.', NULL, NULL,
     'ABERTA', NULL, NOW() - INTERVAL 240 MINUTE, CURDATE() + INTERVAL 4 DAY, NULL, NULL),
    (9, 9, 1, 'Monitor com listras verticais na tela.', 'Painel LCD com defeito; o reparo sai mais caro que um monitor novo.', NULL,
     'CANCELADA', 480.00, CURDATE() - INTERVAL 10 DAY + INTERVAL 780 MINUTE, NULL, NULL, NULL),
    (10, 10, 1, 'Formatação com backup dos arquivos.', 'Backup de 120 GB, formatação e instalação do Windows 11 e do Office.', NULL,
     'EM_REPARO', 220.00, CURDATE() - INTERVAL 3 DAY + INTERVAL 900 MINUTE, CURDATE() + INTERVAL 0 DAY, NULL, NULL),
    (11, 11, 1, 'Bateria não segura carga, desliga com 40%.', NULL, NULL,
     'ABERTA', NULL, CURDATE() - INTERVAL 1 DAY + INTERVAL 600 MINUTE, CURDATE() + INTERVAL 5 DAY, NULL, NULL),
    (12, 12, 1, 'Tablet não carrega.', 'Conector USB-C danificado.', NULL,
     'AGUARDANDO_PECA', 290.00, CURDATE() - INTERVAL 12 DAY + INTERVAL 720 MINUTE, CURDATE() - INTERVAL 3 DAY, NULL, NULL),
    (13, 5, 1, 'Limpeza preventiva.', 'Acúmulo de poeira no cooler.', 'Limpeza interna e troca da pasta térmica.',
     'ENTREGUE', 150.00, CURDATE() - INTERVAL 40 DAY + INTERVAL 840 MINUTE, CURDATE() - INTERVAL 37 DAY, CURDATE() - INTERVAL 37 DAY + INTERVAL 540 MINUTE, CURDATE() - INTERVAL 36 DAY + INTERVAL 780 MINUTE);

INSERT INTO historico_status (ordem_id, status_anterior, status_novo, data_hora, usuario_id, observacao) VALUES
    (1, NULL, 'ABERTA', CURDATE() - INTERVAL 9 DAY + INTERVAL 660 MINUTE, 1, 'Abertura da OS'),
    (1, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 8 DAY + INTERVAL 900 MINUTE, 1, 'Equipamento em bancada'),
    (1, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 7 DAY + INTERVAL 720 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (1, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 6 DAY + INTERVAL 540 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (1, 'EM_REPARO', 'PRONTA', CURDATE() - INTERVAL 5 DAY + INTERVAL 780 MINUTE, 1, 'Cliente avisado para retirada'),
    (1, 'PRONTA', 'ENTREGUE', CURDATE() - INTERVAL 4 DAY + INTERVAL 600 MINUTE, 1, 'Retirado pelo cliente'),
    (2, NULL, 'ABERTA', CURDATE() - INTERVAL 8 DAY + INTERVAL 780 MINUTE, 1, 'Abertura da OS'),
    (2, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 7 DAY + INTERVAL 600 MINUTE, 1, 'Equipamento em bancada'),
    (2, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 6 DAY + INTERVAL 840 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (2, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 4 DAY + INTERVAL 660 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (2, 'EM_REPARO', 'PRONTA', CURDATE() - INTERVAL 3 DAY + INTERVAL 900 MINUTE, 1, 'Cliente avisado para retirada'),
    (2, 'PRONTA', 'ENTREGUE', CURDATE() - INTERVAL 2 DAY + INTERVAL 720 MINUTE, 1, 'Retirado pelo cliente'),
    (3, NULL, 'ABERTA', CURDATE() - INTERVAL 6 DAY + INTERVAL 900 MINUTE, 1, 'Abertura da OS'),
    (3, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 5 DAY + INTERVAL 720 MINUTE, 1, 'Equipamento em bancada'),
    (3, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 4 DAY + INTERVAL 540 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (3, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 2 DAY + INTERVAL 780 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (3, 'EM_REPARO', 'PRONTA', CURDATE() - INTERVAL 1 DAY + INTERVAL 600 MINUTE, 1, 'Cliente avisado para retirada'),
    (4, NULL, 'ABERTA', CURDATE() - INTERVAL 4 DAY + INTERVAL 600 MINUTE, 1, 'Abertura da OS'),
    (4, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 3 DAY + INTERVAL 840 MINUTE, 1, 'Equipamento em bancada'),
    (4, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 2 DAY + INTERVAL 660 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (4, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 1 DAY + INTERVAL 900 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (5, NULL, 'ABERTA', CURDATE() - INTERVAL 7 DAY + INTERVAL 720 MINUTE, 1, 'Abertura da OS'),
    (5, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 6 DAY + INTERVAL 540 MINUTE, 1, 'Equipamento em bancada'),
    (5, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 5 DAY + INTERVAL 780 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (5, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 3 DAY + INTERVAL 600 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (5, 'EM_REPARO', 'AGUARDANDO_PECA', CURDATE() - INTERVAL 2 DAY + INTERVAL 840 MINUTE, 1, 'Peça encomendada do fornecedor'),
    (6, NULL, 'ABERTA', CURDATE() - INTERVAL 3 DAY + INTERVAL 840 MINUTE, 1, 'Abertura da OS'),
    (6, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 2 DAY + INTERVAL 660 MINUTE, 1, 'Equipamento em bancada'),
    (6, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 1 DAY + INTERVAL 900 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (7, NULL, 'ABERTA', CURDATE() - INTERVAL 2 DAY + INTERVAL 540 MINUTE, 1, 'Abertura da OS'),
    (7, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 1 DAY + INTERVAL 780 MINUTE, 1, 'Equipamento em bancada'),
    (8, NULL, 'ABERTA', NOW() - INTERVAL 240 MINUTE, 1, 'Abertura da OS'),
    (9, NULL, 'ABERTA', CURDATE() - INTERVAL 10 DAY + INTERVAL 780 MINUTE, 1, 'Abertura da OS'),
    (9, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 9 DAY + INTERVAL 600 MINUTE, 1, 'Equipamento em bancada'),
    (9, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 9 DAY + INTERVAL 690 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (9, 'AGUARDANDO_APROVACAO', 'CANCELADA', CURDATE() - INTERVAL 8 DAY + INTERVAL 660 MINUTE, 1, 'Cliente recusou o orçamento'),
    (10, NULL, 'ABERTA', CURDATE() - INTERVAL 3 DAY + INTERVAL 900 MINUTE, 1, 'Abertura da OS'),
    (10, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 2 DAY + INTERVAL 720 MINUTE, 1, 'Equipamento em bancada'),
    (10, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 2 DAY + INTERVAL 810 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (10, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 1 DAY + INTERVAL 780 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (11, NULL, 'ABERTA', CURDATE() - INTERVAL 1 DAY + INTERVAL 600 MINUTE, 1, 'Abertura da OS'),
    (12, NULL, 'ABERTA', CURDATE() - INTERVAL 12 DAY + INTERVAL 720 MINUTE, 1, 'Abertura da OS'),
    (12, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 10 DAY + INTERVAL 540 MINUTE, 1, 'Equipamento em bancada'),
    (12, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 8 DAY + INTERVAL 780 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (12, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 6 DAY + INTERVAL 600 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (12, 'EM_REPARO', 'AGUARDANDO_PECA', CURDATE() - INTERVAL 4 DAY + INTERVAL 840 MINUTE, 1, 'Peça encomendada do fornecedor'),
    (13, NULL, 'ABERTA', CURDATE() - INTERVAL 40 DAY + INTERVAL 840 MINUTE, 1, 'Abertura da OS'),
    (13, 'ABERTA', 'EM_ANALISE', CURDATE() - INTERVAL 39 DAY + INTERVAL 660 MINUTE, 1, 'Equipamento em bancada'),
    (13, 'EM_ANALISE', 'AGUARDANDO_APROVACAO', CURDATE() - INTERVAL 38 DAY + INTERVAL 900 MINUTE, 1, 'Orçamento enviado por WhatsApp'),
    (13, 'AGUARDANDO_APROVACAO', 'EM_REPARO', CURDATE() - INTERVAL 38 DAY + INTERVAL 990 MINUTE, 1, 'Cliente aprovou o orçamento'),
    (13, 'EM_REPARO', 'PRONTA', CURDATE() - INTERVAL 37 DAY + INTERVAL 540 MINUTE, 1, 'Cliente avisado para retirada'),
    (13, 'PRONTA', 'ENTREGUE', CURDATE() - INTERVAL 36 DAY + INTERVAL 780 MINUTE, 1, 'Retirado pelo cliente');

ALTER TABLE cliente AUTO_INCREMENT = 100;
ALTER TABLE equipamento AUTO_INCREMENT = 100;
ALTER TABLE ordem_servico AUTO_INCREMENT = 100;
