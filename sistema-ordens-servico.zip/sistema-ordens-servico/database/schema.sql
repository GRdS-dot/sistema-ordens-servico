-- =====================================================================
-- TecOS - Sistema de Ordens de Servico
-- Script de criacao do banco de dados (MySQL 5.6+ / MariaDB 10+)
-- =====================================================================

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS assistencia_os
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE assistencia_os;

-- Usuarios que acessam o sistema (tecnicos / atendentes)
CREATE TABLE IF NOT EXISTS usuario (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nome        VARCHAR(100) NOT NULL,
    login       VARCHAR(50)  NOT NULL UNIQUE,
    senha_hash  VARCHAR(255) NOT NULL,
    ativo       BOOLEAN      NOT NULL DEFAULT TRUE
) ENGINE = InnoDB;

-- Clientes da assistencia
CREATE TABLE IF NOT EXISTS cliente (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    nome           VARCHAR(120) NOT NULL,
    cpf            CHAR(11)     NULL UNIQUE,
    telefone       VARCHAR(20)  NOT NULL,
    email          VARCHAR(120) NULL,
    endereco       VARCHAR(200) NULL,
    data_cadastro  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

-- Equipamentos de cada cliente
CREATE TABLE IF NOT EXISTS equipamento (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id    INT          NOT NULL,
    tipo          VARCHAR(30)  NOT NULL,
    marca         VARCHAR(50)  NOT NULL,
    modelo        VARCHAR(80)  NULL,
    numero_serie  VARCHAR(80)  NULL,
    observacoes   VARCHAR(255) NULL,
    CONSTRAINT fk_equipamento_cliente FOREIGN KEY (cliente_id) REFERENCES cliente (id)
) ENGINE = InnoDB;

-- Ordens de servico
CREATE TABLE IF NOT EXISTS ordem_servico (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    equipamento_id     INT           NOT NULL,
    tecnico_id         INT           NULL,
    defeito_relatado   TEXT          NOT NULL,
    diagnostico        TEXT          NULL,
    servico_executado  TEXT          NULL,
    status             VARCHAR(30)   NOT NULL,
    valor_orcamento    DECIMAL(10,2) NULL,
    data_abertura      DATETIME      NOT NULL,
    data_previsao      DATE          NULL,
    data_conclusao     DATETIME      NULL,
    data_entrega       DATETIME      NULL,
    CONSTRAINT fk_os_equipamento FOREIGN KEY (equipamento_id) REFERENCES equipamento (id),
    CONSTRAINT fk_os_tecnico     FOREIGN KEY (tecnico_id)     REFERENCES usuario (id),
    INDEX idx_os_status (status)
) ENGINE = InnoDB;

-- Historico de cada mudanca de status (auditoria da OS)
CREATE TABLE IF NOT EXISTS historico_status (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    ordem_id         INT          NOT NULL,
    status_anterior  VARCHAR(30)  NULL,
    status_novo      VARCHAR(30)  NOT NULL,
    data_hora        DATETIME     NOT NULL,
    usuario_id       INT          NULL,
    observacao       VARCHAR(255) NULL,
    CONSTRAINT fk_hist_ordem   FOREIGN KEY (ordem_id)   REFERENCES ordem_servico (id) ON DELETE CASCADE,
    CONSTRAINT fk_hist_usuario FOREIGN KEY (usuario_id) REFERENCES usuario (id)
) ENGINE = InnoDB;

-- Usuario inicial: login "admin" / senha "admin123" (troque em producao)
INSERT IGNORE INTO usuario (id, nome, login, senha_hash) VALUES
    (1, 'Administrador', 'admin', 'pbkdf2$120000$A8Q6CxRjmNmScR2o2EHNuA==$CZMbUpbf7I4MLfX7RJZrWhBy+abGILjmT9c4aMV35Dk=');
