package br.com.guilherme.assistencia.util;

import br.com.guilherme.assistencia.App;
import br.com.guilherme.assistencia.dao.DAOException;
import br.com.guilherme.assistencia.service.RegraNegocioException;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;

/** Mensagens padronizadas para o usuario (equivalente ao metodo mensagem() visto em aula). */
public final class Alertas {

    private Alertas() {
    }

    public static void info(String mensagem) {
        mostrar(Alert.AlertType.INFORMATION, "Tudo certo", mensagem);
    }

    public static void aviso(String mensagem) {
        mostrar(Alert.AlertType.WARNING, "Atenção", mensagem);
    }

    /** Erros conhecidos mostram a propria mensagem; erros inesperados vao para o console. */
    public static void erro(Exception e) {
        if (e instanceof RegraNegocioException) {
            aviso(e.getMessage());
        } else if (e instanceof DAOException) {
            mostrar(Alert.AlertType.ERROR, "Erro no banco de dados", e.getMessage());
        } else {
            e.printStackTrace();
            mostrar(Alert.AlertType.ERROR, "Erro inesperado", e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    public static boolean confirmar(String mensagem) {
        Alert alerta = criar(Alert.AlertType.CONFIRMATION, "Confirmar", mensagem);
        Optional<ButtonType> resposta = alerta.showAndWait();
        return resposta.isPresent() && resposta.get() == ButtonType.OK;
    }

    private static void mostrar(Alert.AlertType tipo, String titulo, String mensagem) {
        criar(tipo, titulo, mensagem).showAndWait();
    }

    private static Alert criar(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        if (App.getPalco() != null && App.getPalco().getScene() != null) {
            alerta.initOwner(App.getPalco());
        }
        return alerta;
    }
}
