package br.com.guilherme.assistencia.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class OrdemServico {

    private int id;
    private Equipamento equipamento;
    private Usuario tecnico;
    private String defeitoRelatado;
    private String diagnostico;
    private String servicoExecutado;
    private StatusOS status = StatusOS.ABERTA;
    private BigDecimal valorOrcamento;
    private LocalDateTime dataAbertura;
    private LocalDate dataPrevisao;
    private LocalDateTime dataConclusao;
    private LocalDateTime dataEntrega;

    public OrdemServico() {
    }

    /** O cliente da OS e o dono do equipamento. */
    public Cliente getCliente() {
        return equipamento == null ? null : equipamento.getCliente();
    }

    /** Numero exibido para o cliente, ex.: 000123 */
    public String getNumero() {
        return id == 0 ? "Nova" : String.format("%06d", id);
    }

    /** Atrasada = passou da data prevista e ainda nao foi finalizada nem concluida. */
    public boolean isAtrasada(LocalDate hoje) {
        return dataPrevisao != null
                && dataPrevisao.isBefore(hoje)
                && !status.isFinal()
                && status != StatusOS.PRONTA;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Equipamento getEquipamento() {
        return equipamento;
    }

    public void setEquipamento(Equipamento equipamento) {
        this.equipamento = equipamento;
    }

    public Usuario getTecnico() {
        return tecnico;
    }

    public void setTecnico(Usuario tecnico) {
        this.tecnico = tecnico;
    }

    public String getDefeitoRelatado() {
        return defeitoRelatado;
    }

    public void setDefeitoRelatado(String defeitoRelatado) {
        this.defeitoRelatado = defeitoRelatado;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getServicoExecutado() {
        return servicoExecutado;
    }

    public void setServicoExecutado(String servicoExecutado) {
        this.servicoExecutado = servicoExecutado;
    }

    public StatusOS getStatus() {
        return status;
    }

    public void setStatus(StatusOS status) {
        this.status = status;
    }

    public BigDecimal getValorOrcamento() {
        return valorOrcamento;
    }

    public void setValorOrcamento(BigDecimal valorOrcamento) {
        this.valorOrcamento = valorOrcamento;
    }

    public LocalDateTime getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(LocalDateTime dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public LocalDate getDataPrevisao() {
        return dataPrevisao;
    }

    public void setDataPrevisao(LocalDate dataPrevisao) {
        this.dataPrevisao = dataPrevisao;
    }

    public LocalDateTime getDataConclusao() {
        return dataConclusao;
    }

    public void setDataConclusao(LocalDateTime dataConclusao) {
        this.dataConclusao = dataConclusao;
    }

    public LocalDateTime getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(LocalDateTime dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrdemServico outra)) return false;
        return id != 0 && id == outra.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "OS " + getNumero();
    }
}
