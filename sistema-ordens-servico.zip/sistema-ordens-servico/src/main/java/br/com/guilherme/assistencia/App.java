package br.com.guilherme.assistencia;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.function.Consumer;

/**
 * Ponto de entrada da aplicacao JavaFX.
 * Centraliza o carregamento das telas (FXML) e a troca de cenas.
 */
public class App extends Application {

    public static final String TITULO = "TecOS - Ordens de Serviço";
    private static Stage palco;

    @Override
    public void start(Stage stage) {
        palco = stage;
        palco.setTitle(TITULO);
        mostrarLogin();
        palco.show();
    }

    public static void mostrarLogin() {
        trocarCena("login", 440, 560, false);
    }

    public static void mostrarPrincipal() {
        trocarCena("principal", 1280, 800, true);
        palco.setMinWidth(1100);
        palco.setMinHeight(700);
    }

    private static void trocarCena(String fxml, double largura, double altura, boolean redimensionavel) {
        Scene cena = new Scene(loadFXML(fxml).load(), largura, altura);
        aplicarEstilo(cena);
        palco.setScene(cena);
        palco.setResizable(redimensionavel);
        palco.centerOnScreen();
    }

    /** Cria o carregador de uma tela da pasta view/ (sem a extensao .fxml). */
    public static Carregador loadFXML(String fxml) {
        return new Carregador(new FXMLLoader(App.class.getResource("view/" + fxml + ".fxml")));
    }

    /**
     * Abre uma tela como janela modal e espera ela ser fechada.
     *
     * @param configurar recebe o controller antes da janela aparecer (ex.: para passar a OS a editar)
     * @return o controller, para quem chamou consultar o resultado
     */
    public static <T> T abrirModal(String fxml, String titulo, Consumer<T> configurar) {
        Carregador carregador = loadFXML(fxml);
        Parent raiz = carregador.load();
        T controller = carregador.getController();
        if (configurar != null) configurar.accept(controller);

        Stage janela = new Stage();
        janela.initOwner(palco);
        janela.initModality(Modality.WINDOW_MODAL);
        janela.setTitle(titulo);
        Scene cena = new Scene(raiz);
        aplicarEstilo(cena);
        janela.setScene(cena);
        janela.showAndWait();
        return controller;
    }

    public static void aplicarEstilo(Scene cena) {
        cena.getStylesheets().add(App.class.getResource("styles/estilo.css").toExternalForm());
    }

    public static Stage getPalco() {
        return palco;
    }

    public static void main(String[] args) {
        launch(args);
    }

    /** Pequeno invólucro do FXMLLoader que troca IOException por um erro sem checagem. */
    public static final class Carregador {
        private final FXMLLoader loader;

        private Carregador(FXMLLoader loader) {
            this.loader = loader;
        }

        public Parent load() {
            try {
                return loader.load();
            } catch (IOException e) {
                throw new UncheckedIOException("Erro ao carregar a tela " + loader.getLocation(), e);
            }
        }

        public <T> T getController() {
            return loader.getController();
        }
    }
}
