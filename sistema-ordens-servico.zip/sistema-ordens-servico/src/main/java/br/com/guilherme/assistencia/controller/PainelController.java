package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.dao.OrdemServicoDAO;
import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import br.com.guilherme.assistencia.model.Usuario;
import br.com.guilherme.assistencia.util.Alertas;
import br.com.guilherme.assistencia.util.Formatos;
import br.com.guilherme.assistencia.util.Sessao;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;

import java.math.BigDecimal;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

/** Painel inicial: numeros do dia, grafico por etapa e ordens atrasadas. */
public class PainelController implements Initializable {

    /** Etapas mostradas no grafico (de cima para baixo), com a cor de cada barra. */
    private static final Map<StatusOS, String> CORES = Map.of(
            StatusOS.ABERTA, "#0ea5e9",
            StatusOS.EM_ANALISE, "#8b5cf6",
            StatusOS.AGUARDANDO_APROVACAO, "#f59e0b",
            StatusOS.EM_REPARO, "#2563eb",
            StatusOS.AGUARDANDO_PECA, "#f97316",
            StatusOS.PRONTA, "#22c55e");

    private static final List<StatusOS> ETAPAS = List.of(StatusOS.ABERTA, StatusOS.EM_ANALISE,
            StatusOS.AGUARDANDO_APROVACAO, StatusOS.EM_REPARO, StatusOS.AGUARDANDO_PECA, StatusOS.PRONTA);

    @FXML
    private Label lblSaudacao;
    @FXML
    private Label lblData;
    @FXML
    private Label lblEmAndamento;
    @FXML
    private Label lblProntas;
    @FXML
    private Label lblAtrasadas;
    @FXML
    private Label lblFaturamento;
    @FXML
    private Label lblEntregues;
    @FXML
    private VBox boxAtrasadas;
    @FXML
    private BarChart<Number, String> grafico;
    @FXML
    private TableView<OrdemServico> tblAtrasadas;
    @FXML
    private TableColumn<OrdemServico, String> colAtrNumero;
    @FXML
    private TableColumn<OrdemServico, String> colAtrCliente;
    @FXML
    private TableColumn<OrdemServico, StatusOS> colAtrStatus;
    @FXML
    private TableColumn<OrdemServico, String> colAtrPrevisao;

    private final OrdemServicoDAO ordemDAO = new OrdemServicoDAO();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        LocalDate hoje = LocalDate.now();
        Usuario usuario = Sessao.getUsuarioLogado();
        String nome = usuario == null ? "" : ", " + usuario.getNome().split(" ")[0];
        lblSaudacao.setText(saudacao() + nome);
        lblData.setText(capitalizar(hoje.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM 'de' yyyy",
                Formatos.BRASIL))));

        Tabelas.texto(colAtrNumero, OrdemServico::getNumero);
        Tabelas.texto(colAtrCliente, os -> os.getCliente().getNome());
        Tabelas.status(colAtrStatus, OrdemServico::getStatus);
        Tabelas.texto(colAtrPrevisao, os -> Formatos.data(os.getDataPrevisao()));
        Tabelas.destacarAtraso(colAtrPrevisao, hoje);
        Tabelas.duploClique(tblAtrasadas, this::abrirOrdem);
        Tabelas.colunaFlexivel(tblAtrasadas, colAtrCliente);
        tblAtrasadas.setPlaceholder(new Label("Nenhuma ordem atrasada. Bom trabalho!"));

        carregar();
    }

    private void carregar() {
        try {
            LocalDate hoje = LocalDate.now();
            Map<StatusOS, Integer> contagem = ordemDAO.contarPorStatus();
            List<OrdemServico> atrasadas = ordemDAO.listarAtrasadas(hoje);
            BigDecimal faturado = ordemDAO.faturamento(hoje.minusDays(29), hoje);
            int entregues = ordemDAO.contarEntregues(hoje.minusDays(29), hoje);

            int emAndamento = ETAPAS.stream().filter(s -> s != StatusOS.PRONTA).mapToInt(contagem::get).sum();
            lblEmAndamento.setText(String.valueOf(emAndamento));
            lblProntas.setText(String.valueOf(contagem.get(StatusOS.PRONTA)));
            lblAtrasadas.setText(String.valueOf(atrasadas.size()));
            boxAtrasadas.getStyleClass().remove("indicador-alerta");
            if (!atrasadas.isEmpty()) boxAtrasadas.getStyleClass().add("indicador-alerta");
            lblFaturamento.setText(Formatos.moeda(faturado));
            lblEntregues.setText(entregues == 1 ? "1 ordem entregue" : entregues + " ordens entregues");

            montarGrafico(contagem);
            tblAtrasadas.setItems(FXCollections.observableArrayList(atrasadas));
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
    }

    private void montarGrafico(Map<StatusOS, Integer> contagem) {
        XYChart.Series<Number, String> serie = new XYChart.Series<>();
        // o eixo de categorias desenha de baixo para cima, por isso invertemos a ordem
        for (int i = ETAPAS.size() - 1; i >= 0; i--) {
            StatusOS status = ETAPAS.get(i);
            XYChart.Data<Number, String> barra = new XYChart.Data<>(contagem.get(status), status.getDescricao());
            String cor = CORES.get(status);
            barra.nodeProperty().addListener((obs, antigo, no) -> {
                if (no != null) no.setStyle("-fx-bar-fill: " + cor + ";");
            });
            serie.getData().add(barra);
        }
        grafico.getData().setAll(List.of(serie));

        // escala so com numeros inteiros (nao existe "meia" ordem de servico)
        int maior = contagem.entrySet().stream().filter(e -> ETAPAS.contains(e.getKey()))
                .mapToInt(Map.Entry::getValue).max().orElse(0);
        NumberAxis eixo = (NumberAxis) grafico.getXAxis();
        eixo.setAutoRanging(false);
        eixo.setLowerBound(0);
        eixo.setUpperBound(Math.max(maior, 1) + 1);
        eixo.setTickUnit(1);
    }

    private void abrirOrdem(OrdemServico os) {
        if (OrdemFormController.abrir(os)) carregar();
    }

    @FXML
    private void btnNovaOS_Click(ActionEvent event) {
        if (OrdemFormController.abrir(null)) carregar();
    }

    @FXML
    private void btnAtualizar_Click(ActionEvent event) {
        carregar();
    }

    private static String saudacao() {
        int hora = LocalTime.now().getHour();
        if (hora < 12) return "Bom dia";
        if (hora < 18) return "Boa tarde";
        return "Boa noite";
    }

    private static String capitalizar(String texto) {
        return texto.isEmpty() ? texto : Character.toUpperCase(texto.charAt(0)) + texto.substring(1);
    }
}
