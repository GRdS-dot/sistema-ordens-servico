package br.com.guilherme.assistencia.util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Gera e confere hashes de senha com PBKDF2 (algoritmo nativo do Java).
 * <p>
 * A senha nunca e salva no banco: guardamos "pbkdf2$iteracoes$salt$hash".
 * O salt aleatorio faz duas senhas iguais gerarem hashes diferentes.
 */
public final class Senha {

    private static final String ALGORITMO = "PBKDF2WithHmacSHA256";
    private static final int ITERACOES = 120_000;
    private static final int TAMANHO_SALT = 16;
    private static final int TAMANHO_HASH_BITS = 256;

    private static final SecureRandom RANDOM = new SecureRandom();

    private Senha() {
    }

    public static String gerarHash(String senha) {
        byte[] salt = new byte[TAMANHO_SALT];
        RANDOM.nextBytes(salt);
        byte[] hash = pbkdf2(senha.toCharArray(), salt, ITERACOES);
        Base64.Encoder b64 = Base64.getEncoder();
        return "pbkdf2$" + ITERACOES + "$" + b64.encodeToString(salt) + "$" + b64.encodeToString(hash);
    }

    public static boolean conferir(String senha, String hashSalvo) {
        if (senha == null || hashSalvo == null) return false;
        String[] partes = hashSalvo.split("\\$");
        if (partes.length != 4 || !partes[0].equals("pbkdf2")) return false;
        try {
            int iteracoes = Integer.parseInt(partes[1]);
            byte[] salt = Base64.getDecoder().decode(partes[2]);
            byte[] esperado = Base64.getDecoder().decode(partes[3]);
            byte[] calculado = pbkdf2(senha.toCharArray(), salt, iteracoes);
            // comparacao em tempo constante (evita ataque de tempo)
            return MessageDigest.isEqual(esperado, calculado);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static byte[] pbkdf2(char[] senha, byte[] salt, int iteracoes) {
        try {
            PBEKeySpec spec = new PBEKeySpec(senha, salt, iteracoes, TAMANHO_HASH_BITS);
            return SecretKeyFactory.getInstance(ALGORITMO).generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Nao foi possivel gerar o hash da senha", e);
        }
    }

    /** Utilitario de linha de comando para gerar o hash de uma senha nova. */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Uso: java br.com.guilherme.assistencia.util.Senha <senha>");
            return;
        }
        System.out.println(gerarHash(args[0]));
    }
}
