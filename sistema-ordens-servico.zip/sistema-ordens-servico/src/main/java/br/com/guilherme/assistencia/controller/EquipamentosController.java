package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.dao.ClienteDAO;
import br.com.guilherme.assistencia.dao.EquipamentoDAO;
import br.com.guilherme.assistencia.model.Cliente;
import br.com.guilherme.assistencia.model.Equipamento;
import br.com.guilherme.assistencia.model.TipoEquipamento;
import br.com.guilherme.assistencia.service.EquipamentoService;
import br.com.guilherme.assistencia.util.Alertas;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class EquipamentosController implements Initializable {

    /** Item especial do filtro que representa "todos os clientes". */
    private static final Cliente TODOS = new Cliente("Todos os clientes", null, null, null, null);

    @FXML
    private Label lblTotal;
    @FXML
    private ComboBox<Cliente> cbFiltroCliente;
    @FXML
    private TextField txtPesquisa;
    @FXML
    private TableView<Equipamento> tblEquipamentos;
    @FXML
    private TableColumn<Equipamento, String> colCliente;
    @FXML
    private TableColumn<Equipamento, String> colTipo;
    @FXML
    private TableColumn<Equipamento, String> colMarca;
    @FXML
    private TableColumn<Equipamento, String> colModelo;
    @FXML
    private TableColumn<Equipamento, String> colSerie;
    @FXML
    private Label lblFormulario;
    @FXML
    private ComboBox<Cliente> cbCliente;
    @FXML
    private ComboBox<TipoEquipamento> cbTipo;
    @FXML
    private TextField txtMarca;
    @FXML
    private TextField txtModelo;
    @FXML
    private TextField txtSerie;
    @FXML
    private TextArea txtObservacoes;
    @FXML
    private Button btnExcluir;

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final EquipamentoDAO equipamentoDAO = new EquipamentoDAO();
    private final EquipamentoService equipamentoService = new EquipamentoService();

    private Equipamento selecionado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Tabelas.texto(colCliente, e -> e.getCliente().getNome());
        Tabelas.texto(colTipo, e -> e.getTipo().getDescricao());
        Tabelas.texto(colMarca, Equipamento::getMarca);
        Tabelas.texto(colModelo, Equipamento::getModelo);
        Tabelas.texto(colSerie, Equipamento::getNumeroSerie);
        tblEquipamentos.setPlaceholder(new Label("Nenhum equipamento encontrado."));
        Tabelas.colunaFlexivel(tblEquipamentos, colModelo);

        cbTipo.setItems(FXCollections.observableArrayList(TipoEquipamento.values()));
        carregarClientes();

        tblEquipamentos.getSelectionModel().selectedItemProperty()
                .addListener((obs, antigo, equipamento) -> preencherFormulario(equipamento));
        cbFiltroCliente.valueProperty().addListener((obs, antigo, novo) -> carregarTabela());
        txtPesquisa.textProperty().addListener((obs, antigo, novo) -> carregarTabela());

        limparFormulario();
        carregarTabela();
    }

    private void carregarClientes() {
        try {
            List<Cliente> clientes = clienteDAO.listar();
            cbCliente.setItems(FXCollections.observableArrayList(clientes));

            ObservableList<Cliente> filtro = FXCollections.observableArrayList(TODOS);
            filtro.addAll(clientes);
            cbFiltroCliente.setItems(filtro);
            cbFiltroCliente.setValue(TODOS);
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
    }

    private void carregarTabela() {
        try {
            Cliente filtro = cbFiltroCliente.getValue() == TODOS ? null : cbFiltroCliente.getValue();
            List<Equipamento> lista = equipamentoDAO.pesquisar(filtro, txtPesquisa.getText());
            tblEquipamentos.setItems(FXCollections.observableArrayList(lista));
            lblTotal.setText(lista.size() == 1 ? "1 equipamento" : lista.size() + " equipamentos");
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
    }

    private void preencherFormulario(Equipamento e) {
        if (e == null) return;
        selecionado = e;
        lblFormulario.setText("Editar equipamento");
        cbCliente.setValue(e.getCliente());
        cbTipo.setValue(e.getTipo());
        txtMarca.setText(e.getMarca());
        txtModelo.setText(e.getModelo());
        txtSerie.setText(e.getNumeroSerie());
        txtObservacoes.setText(e.getObservacoes());
        btnExcluir.setDisable(false);
    }

    private void limparFormulario() {
        selecionado = null;
        lblFormulario.setText("Novo equipamento");
        // ao cadastrar com um cliente filtrado, ja sugere esse cliente
        Cliente filtro = cbFiltroCliente.getValue();
        cbCliente.setValue(filtro == null || filtro == TODOS ? null : filtro);
        cbTipo.setValue(null);
        txtMarca.clear();
        txtModelo.clear();
        txtSerie.clear();
        txtObservacoes.clear();
        btnExcluir.setDisable(true);
        tblEquipamentos.getSelectionModel().clearSelection();
    }

    @FXML
    private void btnNovo_Click(ActionEvent event) {
        limparFormulario();
    }

    @FXML
    private void btnSalvar_Click(ActionEvent event) {
        Equipamento e = selecionado == null ? new Equipamento() : selecionado;
        e.setCliente(cbCliente.getValue());
        e.setTipo(cbTipo.getValue());
        e.setMarca(txtMarca.getText());
        e.setModelo(txtModelo.getText());
        e.setNumeroSerie(txtSerie.getText());
        e.setObservacoes(txtObservacoes.getText());

        try {
            equipamentoService.validar(e);
            if (e.getId() == 0) {
                equipamentoDAO.insere(e);
            } else {
                equipamentoDAO.alterar(e);
            }
            Alertas.info("Equipamento \"" + e.getDescricao() + "\" salvo com sucesso.");
            limparFormulario();
            carregarTabela();
        } catch (RuntimeException ex) {
            Alertas.erro(ex);
            carregarTabela();
        }
    }

    @FXML
    private void btnExcluir_Click(ActionEvent event) {
        if (selecionado == null) return;
        if (!Alertas.confirmar("Excluir o equipamento \"" + selecionado.getDescricao() + "\"?")) return;
        try {
            equipamentoDAO.remover(selecionado.getId());
            limparFormulario();
            carregarTabela();
        } catch (RuntimeException ex) {
            Alertas.erro(ex);
        }
    }
}
