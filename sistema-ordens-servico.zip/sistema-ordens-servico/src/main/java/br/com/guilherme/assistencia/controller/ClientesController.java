package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.dao.ClienteDAO;
import br.com.guilherme.assistencia.model.Cliente;
import br.com.guilherme.assistencia.service.ClienteService;
import br.com.guilherme.assistencia.util.Alertas;
import br.com.guilherme.assistencia.util.Validador;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/** Cadastro de clientes: lista com busca a esquerda e formulario a direita. */
public class ClientesController implements Initializable {

    @FXML
    private Label lblTotal;
    @FXML
    private TextField txtPesquisa;
    @FXML
    private TableView<Cliente> tblClientes;
    @FXML
    private TableColumn<Cliente, String> colNome;
    @FXML
    private TableColumn<Cliente, String> colCpf;
    @FXML
    private TableColumn<Cliente, String> colTelefone;
    @FXML
    private TableColumn<Cliente, String> colEmail;
    @FXML
    private Label lblFormulario;
    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtTelefone;
    @FXML
    private TextField txtCpf;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtEndereco;
    @FXML
    private Button btnExcluir;

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final ClienteService clienteService = new ClienteService();

    /** Cliente em edicao (null = cadastrando um novo). */
    private Cliente selecionado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Tabelas.texto(colNome, Cliente::getNome);
        Tabelas.texto(colCpf, c -> Validador.formatarCpf(c.getCpf()));
        Tabelas.texto(colTelefone, c -> Validador.formatarTelefone(c.getTelefone()));
        Tabelas.texto(colEmail, Cliente::getEmail);
        tblClientes.setPlaceholder(new Label("Nenhum cliente encontrado."));
        Tabelas.colunaFlexivel(tblClientes, colNome);

        tblClientes.getSelectionModel().selectedItemProperty()
                .addListener((obs, antigo, cliente) -> preencherFormulario(cliente));
        // busca enquanto digita
        txtPesquisa.textProperty().addListener((obs, antigo, novo) -> carregarTabela());

        limparFormulario();
        carregarTabela();
    }

    private void carregarTabela() {
        try {
            List<Cliente> clientes = clienteDAO.pesquisar(txtPesquisa.getText());
            tblClientes.setItems(FXCollections.observableArrayList(clientes));
            lblTotal.setText(clientes.size() == 1 ? "1 cliente" : clientes.size() + " clientes");
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
    }

    private void preencherFormulario(Cliente cliente) {
        if (cliente == null) return;
        selecionado = cliente;
        lblFormulario.setText("Editar cliente");
        txtNome.setText(cliente.getNome());
        txtTelefone.setText(Validador.formatarTelefone(cliente.getTelefone()));
        txtCpf.setText(Validador.formatarCpf(cliente.getCpf()));
        txtEmail.setText(cliente.getEmail());
        txtEndereco.setText(cliente.getEndereco());
        btnExcluir.setDisable(false);
    }

    private void limparFormulario() {
        selecionado = null;
        lblFormulario.setText("Novo cliente");
        for (TextField campo : List.of(txtNome, txtTelefone, txtCpf, txtEmail, txtEndereco)) {
            campo.clear();
        }
        btnExcluir.setDisable(true);
        tblClientes.getSelectionModel().clearSelection();
        txtNome.requestFocus();
    }

    @FXML
    private void btnNovo_Click(ActionEvent event) {
        limparFormulario();
    }

    @FXML
    private void btnSalvar_Click(ActionEvent event) {
        Cliente cliente = selecionado == null ? new Cliente() : selecionado;
        cliente.setNome(txtNome.getText());
        cliente.setTelefone(txtTelefone.getText());
        cliente.setCpf(txtCpf.getText());
        cliente.setEmail(txtEmail.getText());
        cliente.setEndereco(txtEndereco.getText());

        try {
            clienteService.validar(cliente);
            if (cliente.getId() == 0) {
                clienteDAO.insere(cliente);
            } else {
                clienteDAO.alterar(cliente);
            }
            Alertas.info("Cliente \"" + cliente.getNome() + "\" salvo com sucesso.");
            limparFormulario();
            carregarTabela();
        } catch (RuntimeException e) {
            Alertas.erro(e);
            carregarTabela();   // desfaz alteracoes nao salvas na tabela
        }
    }

    @FXML
    private void btnExcluir_Click(ActionEvent event) {
        if (selecionado == null) return;
        if (!Alertas.confirmar("Excluir o cliente \"" + selecionado.getNome() + "\"?")) return;
        try {
            clienteDAO.remover(selecionado.getId());
            limparFormulario();
            carregarTabela();
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
    }
}
