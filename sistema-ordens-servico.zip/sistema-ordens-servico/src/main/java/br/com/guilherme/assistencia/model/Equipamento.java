package br.com.guilherme.assistencia.model;

import java.util.Objects;

public class Equipamento {

    private int id;
    private Cliente cliente;
    private TipoEquipamento tipo;
    private String marca;
    private String modelo;
    private String numeroSerie;
    private String observacoes;

    public Equipamento() {
    }

    public Equipamento(Cliente cliente, TipoEquipamento tipo, String marca, String modelo) {
        this.cliente = cliente;
        this.tipo = tipo;
        this.marca = marca;
        this.modelo = modelo;
    }

    /** Ex.: "Notebook Dell Inspiron 15" */
    public String getDescricao() {
        StringBuilder sb = new StringBuilder();
        if (tipo != null) sb.append(tipo.getDescricao()).append(' ');
        if (marca != null) sb.append(marca);
        if (modelo != null && !modelo.isBlank()) sb.append(' ').append(modelo);
        return sb.toString().trim();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public TipoEquipamento getTipo() {
        return tipo;
    }

    public void setTipo(TipoEquipamento tipo) {
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Equipamento outro)) return false;
        return id != 0 && id == outro.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return getDescricao();
    }
}
