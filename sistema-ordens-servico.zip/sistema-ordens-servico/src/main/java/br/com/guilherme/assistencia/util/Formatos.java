package br.com.guilherme.assistencia.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Formatacao de valores e datas no padrao brasileiro. */
public final class Formatos {

    public static final Locale BRASIL = Locale.forLanguageTag("pt-BR");
    public static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private Formatos() {
    }

    public static String moeda(BigDecimal valor) {
        if (valor == null) return "";
        return NumberFormat.getCurrencyInstance(BRASIL).format(valor).replace(' ', ' ');
    }

    public static String data(LocalDate data) {
        return data == null ? "" : DATA.format(data);
    }

    public static String data(LocalDateTime dataHora) {
        return dataHora == null ? "" : DATA.format(dataHora);
    }

    public static String dataHora(LocalDateTime dataHora) {
        return dataHora == null ? "" : DATA_HORA.format(dataHora);
    }

    /**
     * Converte o texto digitado em valor: aceita "150", "150,90", "1.250,00" e "R$ 80".
     * Retorna null se o campo estiver vazio.
     *
     * @throws NumberFormatException se o texto nao for um valor valido
     */
    public static BigDecimal lerValor(String texto) {
        if (texto == null || texto.isBlank()) return null;
        String limpo = texto.replace("R$", "").replace(" ", "").trim();
        if (limpo.contains(",")) {
            limpo = limpo.replace(".", "").replace(',', '.');
        }
        return new BigDecimal(limpo).setScale(2, java.math.RoundingMode.HALF_UP);
    }

    /** Valor para exibir em campo de edicao: 1250.5 -> "1250,50" */
    public static String valorEditavel(BigDecimal valor) {
        return valor == null ? "" : valor.setScale(2, java.math.RoundingMode.HALF_UP).toPlainString().replace('.', ',');
    }
}
