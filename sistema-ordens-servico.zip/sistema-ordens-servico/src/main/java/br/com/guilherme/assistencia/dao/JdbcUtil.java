package br.com.guilherme.assistencia.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** Conversoes entre tipos do Java e do JDBC, tratando valores nulos. */
final class JdbcUtil {

    private JdbcUtil() {
    }

    static void setTexto(PreparedStatement ps, int indice, String valor) throws SQLException {
        if (valor == null) ps.setNull(indice, Types.VARCHAR);
        else ps.setString(indice, valor);
    }

    static void setDataHora(PreparedStatement ps, int indice, LocalDateTime valor) throws SQLException {
        if (valor == null) ps.setNull(indice, Types.TIMESTAMP);
        else ps.setTimestamp(indice, Timestamp.valueOf(valor));
    }

    static void setData(PreparedStatement ps, int indice, LocalDate valor) throws SQLException {
        if (valor == null) ps.setNull(indice, Types.DATE);
        else ps.setDate(indice, Date.valueOf(valor));
    }

    static void setInteiro(PreparedStatement ps, int indice, Integer valor) throws SQLException {
        if (valor == null || valor == 0) ps.setNull(indice, Types.INTEGER);
        else ps.setInt(indice, valor);
    }

    static LocalDateTime getDataHora(ResultSet rs, String coluna) throws SQLException {
        Timestamp t = rs.getTimestamp(coluna);
        return t == null ? null : t.toLocalDateTime();
    }

    static LocalDate getData(ResultSet rs, String coluna) throws SQLException {
        Date d = rs.getDate(coluna);
        return d == null ? null : d.toLocalDate();
    }

    /** Monta o termo para LIKE: "dell" -> "%dell%" */
    static String like(String termo) {
        return "%" + (termo == null ? "" : termo.trim()) + "%";
    }
}
