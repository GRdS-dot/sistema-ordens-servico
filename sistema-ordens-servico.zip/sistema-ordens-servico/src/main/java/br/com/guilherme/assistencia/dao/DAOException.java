package br.com.guilherme.assistencia.dao;

import java.sql.SQLException;

/**
 * Erro de acesso ao banco. Os erros mais comuns do MySQL sao traduzidos
 * para mensagens que o usuario entende.
 */
public class DAOException extends RuntimeException {

    public DAOException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }

    /**
     * @param e        erro original do JDBC
     * @param contexto o que estava sendo feito, ex.: "salvar o cliente"
     */
    public static DAOException traduzir(SQLException e, String contexto) {
        return traduzir(e, contexto, "Não foi possível " + contexto + ": existem registros vinculados a ele.");
    }

    /**
     * @param mensagemVinculo mensagem usada quando o registro nao pode ser excluido
     *                        porque outra tabela aponta para ele (chave estrangeira)
     */
    public static DAOException traduzir(SQLException e, String contexto, String mensagemVinculo) {
        String estado = e.getSQLState() == null ? "" : e.getSQLState();
        int codigo = e.getErrorCode();

        if (codigo == 1062) {                       // chave unica duplicada
            String detalhe = e.getMessage() != null && e.getMessage().contains("cpf")
                    ? "Já existe um cliente cadastrado com este CPF."
                    : "Já existe um registro com estes dados.";
            return new DAOException(detalhe, e);
        }
        if (codigo == 1451) {                       // registro usado em outra tabela (FK)
            return new DAOException(mensagemVinculo, e);
        }
        if (estado.startsWith("08")) {              // falha de conexao
            return new DAOException("Sem conexão com o banco de dados. Verifique se o MySQL está ligado.", e);
        }
        return new DAOException("Erro ao " + contexto + ": " + e.getMessage(), e);
    }
}
