package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.App;
import br.com.guilherme.assistencia.dao.Banco;
import br.com.guilherme.assistencia.dao.DAOException;
import br.com.guilherme.assistencia.dao.UsuarioDAO;
import br.com.guilherme.assistencia.model.Usuario;
import br.com.guilherme.assistencia.util.Sessao;
import br.com.guilherme.assistencia.util.Validador;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private TextField txtLogin;
    @FXML
    private PasswordField txtSenha;
    @FXML
    private Label lblErro;

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Platform.runLater(() -> txtLogin.requestFocus());
    }

    @FXML
    private void btnEntrar_Click(ActionEvent event) {
        if (Validador.vazio(txtLogin.getText()) || Validador.vazio(txtSenha.getText())) {
            mostrarErro("Informe o usuário e a senha.");
            return;
        }

        try {
            Optional<Usuario> usuario = usuarioDAO.autenticar(txtLogin.getText(), txtSenha.getText());
            if (usuario.isEmpty()) {
                mostrarErro("Usuário ou senha incorretos.");
                txtSenha.clear();
                txtSenha.requestFocus();
                return;
            }
            Sessao.iniciar(usuario.get());
            App.mostrarPrincipal();
        } catch (DAOException e) {
            mostrarErro("Não foi possível conectar ao banco de dados (" + Banco.getUrl().split("\\?")[0]
                    + "). Verifique se o MySQL está ligado e se o arquivo banco.properties está correto.");
            e.printStackTrace();
        }
    }

    private void mostrarErro(String mensagem) {
        lblErro.setText(mensagem);
        lblErro.setManaged(true);
        lblErro.setVisible(true);
    }
}
