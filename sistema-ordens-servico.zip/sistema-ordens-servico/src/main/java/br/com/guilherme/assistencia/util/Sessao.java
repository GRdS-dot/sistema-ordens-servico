package br.com.guilherme.assistencia.util;

import br.com.guilherme.assistencia.model.Usuario;

/** Guarda o usuario que fez login, para registrar quem alterou cada OS. */
public final class Sessao {

    private static Usuario usuarioLogado;

    private Sessao() {
    }

    public static Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public static void iniciar(Usuario usuario) {
        usuarioLogado = usuario;
    }

    public static void encerrar() {
        usuarioLogado = null;
    }
}
