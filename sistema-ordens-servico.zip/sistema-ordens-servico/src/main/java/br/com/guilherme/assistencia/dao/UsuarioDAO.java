package br.com.guilherme.assistencia.dao;

import br.com.guilherme.assistencia.model.Usuario;
import br.com.guilherme.assistencia.util.Senha;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UsuarioDAO implements DAO<Usuario> {

    private static final String COLUNAS = "id, nome, login, senha_hash, ativo";

    /**
     * Confere login e senha.
     *
     * @return o usuario, se o login existir, estiver ativo e a senha conferir
     */
    public Optional<Usuario> autenticar(String login, String senha) {
        String sql = "SELECT " + COLUNAS + " FROM usuario WHERE login = ? AND ativo = TRUE";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, login == null ? "" : login.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = montar(rs);
                    if (Senha.conferir(senha, u.getSenhaHash())) {
                        return Optional.of(u);
                    }
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "fazer login");
        }
    }

    @Override
    public void insere(Usuario u) {
        String sql = "INSERT INTO usuario (nome, login, senha_hash, ativo) VALUES (?, ?, ?, ?)";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, u.getNome());
            ps.setString(2, u.getLogin());
            ps.setString(3, u.getSenhaHash());
            ps.setBoolean(4, u.isAtivo());
            ps.executeUpdate();
            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) u.setId(chaves.getInt(1));
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "salvar o usuário");
        }
    }

    @Override
    public void alterar(Usuario u) {
        String sql = "UPDATE usuario SET nome = ?, login = ?, senha_hash = ?, ativo = ? WHERE id = ?";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNome());
            ps.setString(2, u.getLogin());
            ps.setString(3, u.getSenhaHash());
            ps.setBoolean(4, u.isAtivo());
            ps.setInt(5, u.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "alterar o usuário");
        }
    }

    @Override
    public void remover(int id) {
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement("DELETE FROM usuario WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "excluir o usuário",
                    "Este usuário já registrou ordens de serviço. Desative-o em vez de excluir.");
        }
    }

    @Override
    public Usuario buscarID(int id) {
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement("SELECT " + COLUNAS + " FROM usuario WHERE id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? montar(rs) : null;
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "buscar o usuário");
        }
    }

    @Override
    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement("SELECT " + COLUNAS + " FROM usuario ORDER BY nome");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(montar(rs));
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "listar os usuários");
        }
        return lista;
    }

    private static Usuario montar(ResultSet rs) throws SQLException {
        Usuario u = new Usuario(rs.getInt("id"), rs.getString("nome"), rs.getString("login"));
        u.setSenhaHash(rs.getString("senha_hash"));
        u.setAtivo(rs.getBoolean("ativo"));
        return u;
    }
}
