package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.App;
import br.com.guilherme.assistencia.model.Usuario;
import br.com.guilherme.assistencia.util.Alertas;
import br.com.guilherme.assistencia.util.Sessao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/** Tela principal: menu lateral fixo e a area central que troca de conteudo. */
public class PrincipalController implements Initializable {

    @FXML
    private StackPane conteudo;
    @FXML
    private Button btnPainel;
    @FXML
    private Button btnOrdens;
    @FXML
    private Button btnClientes;
    @FXML
    private Button btnEquipamentos;
    @FXML
    private Label lblUsuario;
    @FXML
    private Label lblLogin;

    /** Telas que podem ser abertas pelo menu. */
    public enum Tela {
        PAINEL("painel"), ORDENS("ordens"), CLIENTES("clientes"), EQUIPAMENTOS("equipamentos");

        private final String fxml;

        Tela(String fxml) {
            this.fxml = fxml;
        }
    }

    private static PrincipalController atual;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        atual = this;
        Usuario usuario = Sessao.getUsuarioLogado();
        if (usuario != null) {
            lblUsuario.setText(usuario.getNome());
            lblLogin.setText("@" + usuario.getLogin());
        }
        mostrar(Tela.PAINEL);
    }

    /** Permite que outras telas naveguem (ex.: o painel abrindo a lista de OS). */
    public static void irPara(Tela tela) {
        if (atual != null) atual.mostrar(tela);
    }

    private void mostrar(Tela tela) {
        try {
            conteudo.getChildren().setAll(App.loadFXML(tela.fxml).load());
        } catch (RuntimeException e) {
            Alertas.erro(e);
            return;
        }
        Button ativo = switch (tela) {
            case PAINEL -> btnPainel;
            case ORDENS -> btnOrdens;
            case CLIENTES -> btnClientes;
            case EQUIPAMENTOS -> btnEquipamentos;
        };
        for (Button b : List.of(btnPainel, btnOrdens, btnClientes, btnEquipamentos)) {
            b.getStyleClass().remove("ativo");
        }
        ativo.getStyleClass().add("ativo");
    }

    @FXML
    private void btnPainel_Click(ActionEvent event) {
        mostrar(Tela.PAINEL);
    }

    @FXML
    private void btnOrdens_Click(ActionEvent event) {
        mostrar(Tela.ORDENS);
    }

    @FXML
    private void btnClientes_Click(ActionEvent event) {
        mostrar(Tela.CLIENTES);
    }

    @FXML
    private void btnEquipamentos_Click(ActionEvent event) {
        mostrar(Tela.EQUIPAMENTOS);
    }

    @FXML
    private void btnSair_Click(ActionEvent event) {
        if (Alertas.confirmar("Deseja sair do sistema?")) {
            Sessao.encerrar();
            atual = null;
            App.mostrarLogin();
        }
    }
}
