package br.com.guilherme.assistencia.service;

import br.com.guilherme.assistencia.model.Cliente;
import br.com.guilherme.assistencia.util.Validador;

import java.util.ArrayList;
import java.util.List;

/** Regras de cadastro de cliente. Nao depende de banco nem de tela, por isso e facil de testar. */
public class ClienteService {

    /**
     * Valida e normaliza o cliente (CPF e telefone ficam so com digitos).
     *
     * @throws RegraNegocioException com todos os problemas encontrados, um por linha
     */
    public void validar(Cliente cliente) {
        List<String> erros = new ArrayList<>();

        if (Validador.vazio(cliente.getNome()) || cliente.getNome().trim().length() < 3) {
            erros.add("Informe o nome do cliente (mínimo de 3 letras).");
        }
        if (!Validador.telefoneValido(cliente.getTelefone())) {
            erros.add("Informe um telefone com DDD (10 ou 11 dígitos).");
        }
        if (!Validador.vazio(cliente.getCpf()) && !Validador.cpfValido(cliente.getCpf())) {
            erros.add("CPF inválido.");
        }
        if (!Validador.vazio(cliente.getEmail()) && !Validador.emailValido(cliente.getEmail())) {
            erros.add("E-mail inválido.");
        }

        if (!erros.isEmpty()) {
            throw new RegraNegocioException(String.join("\n", erros));
        }

        cliente.setNome(cliente.getNome().trim());
        cliente.setTelefone(Validador.somenteDigitos(cliente.getTelefone()));
        cliente.setCpf(Validador.vazio(cliente.getCpf()) ? null : Validador.somenteDigitos(cliente.getCpf()));
        cliente.setEmail(Validador.vazio(cliente.getEmail()) ? null : cliente.getEmail().trim());
        cliente.setEndereco(Validador.vazio(cliente.getEndereco()) ? null : cliente.getEndereco().trim());
    }
}
