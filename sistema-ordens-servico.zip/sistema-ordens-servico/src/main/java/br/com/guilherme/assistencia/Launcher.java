package br.com.guilherme.assistencia;

/**
 * Classe de partida que NAO estende Application.
 * Permite rodar o sistema pelo botao "Run" de qualquer IDE ou por um .jar,
 * sem o erro "JavaFX runtime components are missing".
 */
public class Launcher {

    public static void main(String[] args) {
        App.main(args);
    }
}
