package br.com.guilherme.assistencia.dao;

import br.com.guilherme.assistencia.model.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO implements DAO<Cliente> {

    private static final String COLUNAS = "id, nome, cpf, telefone, email, endereco, data_cadastro";

    @Override
    public void insere(Cliente c) {
        String sql = "INSERT INTO cliente (nome, cpf, telefone, email, endereco) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preencher(ps, c);
            ps.executeUpdate();
            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) c.setId(chaves.getInt(1));
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "salvar o cliente");
        }
    }

    @Override
    public void alterar(Cliente c) {
        String sql = "UPDATE cliente SET nome = ?, cpf = ?, telefone = ?, email = ?, endereco = ? WHERE id = ?";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            preencher(ps, c);
            ps.setInt(6, c.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "alterar o cliente");
        }
    }

    @Override
    public void remover(int id) {
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement("DELETE FROM cliente WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "excluir o cliente",
                    "Este cliente possui equipamentos cadastrados e não pode ser excluído.");
        }
    }

    @Override
    public Cliente buscarID(int id) {
        String sql = "SELECT " + COLUNAS + " FROM cliente WHERE id = ?";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? montar(rs) : null;
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "buscar o cliente");
        }
    }

    @Override
    public List<Cliente> listar() {
        return pesquisar("");
    }

    /** Busca por parte do nome, CPF ou telefone. */
    public List<Cliente> pesquisar(String termo) {
        String sql = "SELECT " + COLUNAS + " FROM cliente "
                + "WHERE nome LIKE ? OR cpf LIKE ? OR telefone LIKE ? ORDER BY nome";
        List<Cliente> lista = new ArrayList<>();
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String like = JdbcUtil.like(termo);
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(montar(rs));
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "listar os clientes");
        }
        return lista;
    }

    private void preencher(PreparedStatement ps, Cliente c) throws SQLException {
        ps.setString(1, c.getNome());
        JdbcUtil.setTexto(ps, 2, c.getCpf());
        ps.setString(3, c.getTelefone());
        JdbcUtil.setTexto(ps, 4, c.getEmail());
        JdbcUtil.setTexto(ps, 5, c.getEndereco());
    }

    /** Transforma a linha atual do ResultSet em um Cliente. */
    static Cliente montar(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setId(rs.getInt("id"));
        c.setNome(rs.getString("nome"));
        c.setCpf(rs.getString("cpf"));
        c.setTelefone(rs.getString("telefone"));
        c.setEmail(rs.getString("email"));
        c.setEndereco(rs.getString("endereco"));
        c.setDataCadastro(JdbcUtil.getDataHora(rs, "data_cadastro"));
        return c;
    }
}
