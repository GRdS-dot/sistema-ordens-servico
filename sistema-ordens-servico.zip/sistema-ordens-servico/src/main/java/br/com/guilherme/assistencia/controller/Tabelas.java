package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Region;

import java.util.function.Consumer;
import java.util.function.Function;

/** Atalhos para configurar colunas de TableView sem repetir codigo em cada tela. */
final class Tabelas {

    private Tabelas() {
    }

    /** Coluna de texto: o valor e calculado a partir do objeto da linha. */
    static <T> void texto(TableColumn<T, String> coluna, Function<T, String> valor) {
        coluna.setCellValueFactory(dados -> {
            String texto = valor.apply(dados.getValue());
            return new SimpleStringProperty(texto == null ? "" : texto);
        });
    }

    /** Coluna de status com a "etiqueta" colorida. */
    static <T> void status(TableColumn<T, StatusOS> coluna, Function<T, StatusOS> valor) {
        coluna.setCellValueFactory(dados -> new SimpleObjectProperty<>(valor.apply(dados.getValue())));
        coluna.setCellFactory(c -> new TableCell<>() {
            private final Label etiqueta = new Label();

            {
                etiqueta.setMinWidth(Region.USE_PREF_SIZE);   // a etiqueta nunca e cortada
            }

            @Override
            protected void updateItem(StatusOS status, boolean vazio) {
                super.updateItem(status, vazio);
                if (vazio || status == null) {
                    setGraphic(null);
                } else {
                    etiqueta.setText(status.getDescricao());
                    etiqueta.getStyleClass().setAll("label", "status", status.getClasseCss());
                    setGraphic(etiqueta);
                }
                setText(null);
            }
        });
    }

    /** Pinta de vermelho o texto da coluna quando a OS esta atrasada. */
    static void destacarAtraso(TableColumn<OrdemServico, String> coluna, java.time.LocalDate hoje) {
        coluna.setCellFactory(c -> new TableCell<>() {
            @Override
            protected void updateItem(String texto, boolean vazio) {
                super.updateItem(texto, vazio);
                setText(vazio ? null : texto);
                getStyleClass().remove("texto-atrasado");
                TableRow<OrdemServico> linha = getTableRow();
                if (!vazio && linha != null && linha.getItem() != null && linha.getItem().isAtrasada(hoje)) {
                    getStyleClass().add("texto-atrasado");
                }
            }
        });
    }

    /**
     * Faz uma coluna ocupar o espaco que sobra na tabela; as outras mantem a largura do FXML.
     * (A politica CONSTRAINED_RESIZE_POLICY do JavaFX ignora as larguras definidas.)
     */
    static <T> void colunaFlexivel(TableView<T> tabela, TableColumn<T, ?> flexivel) {
        tabela.widthProperty().addListener((obs, antiga, largura) -> {
            double ocupado = 0;
            for (TableColumn<T, ?> c : tabela.getColumns()) {
                if (c != flexivel) ocupado += c.getWidth();
            }
            // desconta bordas e a barra de rolagem vertical
            flexivel.setPrefWidth(Math.max(flexivel.getMinWidth(), largura.doubleValue() - ocupado - 26));
        });
    }

    /** Executa a acao no duplo clique de uma linha. */
    static <T> void duploClique(TableView<T> tabela, Consumer<T> acao) {
        tabela.setRowFactory(t -> {
            TableRow<T> linha = new TableRow<>();
            linha.setOnMouseClicked(evento -> {
                if (evento.getButton() == MouseButton.PRIMARY && evento.getClickCount() == 2 && !linha.isEmpty()) {
                    acao.accept(linha.getItem());
                }
            });
            return linha;
        });
    }
}
