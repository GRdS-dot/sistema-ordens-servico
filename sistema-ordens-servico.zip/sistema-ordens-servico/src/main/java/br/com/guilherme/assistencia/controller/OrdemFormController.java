package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.App;
import br.com.guilherme.assistencia.dao.ClienteDAO;
import br.com.guilherme.assistencia.dao.EquipamentoDAO;
import br.com.guilherme.assistencia.dao.OrdemServicoDAO;
import br.com.guilherme.assistencia.model.Cliente;
import br.com.guilherme.assistencia.model.Equipamento;
import br.com.guilherme.assistencia.model.HistoricoStatus;
import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import br.com.guilherme.assistencia.service.OrdemServicoService;
import br.com.guilherme.assistencia.service.RegraNegocioException;
import br.com.guilherme.assistencia.util.Alertas;
import br.com.guilherme.assistencia.util.Formatos;
import br.com.guilherme.assistencia.util.Sessao;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Janela de abertura e acompanhamento de uma ordem de servico.
 * <p>
 * Nova OS: o usuario escolhe cliente e equipamento e descreve o defeito.
 * OS existente: alem de editar os campos, avanca o status e ve o historico.
 */
public class OrdemFormController implements Initializable {

    @FXML
    private Label lblTitulo;
    @FXML
    private Label lblSubtitulo;
    @FXML
    private Label lblStatus;
    @FXML
    private ComboBox<Cliente> cbCliente;
    @FXML
    private ComboBox<Equipamento> cbEquipamento;
    @FXML
    private Label lblSemEquipamento;
    @FXML
    private TextArea txtDefeito;
    @FXML
    private TextArea txtDiagnostico;
    @FXML
    private TextArea txtServico;
    @FXML
    private TextField txtValor;
    @FXML
    private DatePicker dpPrevisao;
    @FXML
    private VBox painelAndamento;
    @FXML
    private Label lblDicaStatus;
    @FXML
    private ComboBox<StatusOS> cbProximoStatus;
    @FXML
    private TextField txtObservacao;
    @FXML
    private Button btnAplicarStatus;
    @FXML
    private ListView<HistoricoStatus> lstHistorico;
    @FXML
    private Label lblDatas;
    @FXML
    private Button btnSalvar;

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final EquipamentoDAO equipamentoDAO = new EquipamentoDAO();
    private final OrdemServicoDAO ordemDAO = new OrdemServicoDAO();
    private final OrdemServicoService ordemService = new OrdemServicoService();

    private OrdemServico os;
    private boolean alterou;

    /**
     * Abre a janela da OS.
     *
     * @param os a OS a editar, ou null para abrir uma nova
     * @return true se algo foi salvo (para a tela de origem recarregar a lista)
     */
    public static boolean abrir(OrdemServico os) {
        String titulo = os == null ? "Nova ordem de serviço" : "Ordem de serviço " + os.getNumero();
        OrdemFormController controller = App.abrirModal("ordem_form", titulo, c -> c.carregar(os));
        return controller.alterou;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dpPrevisao.setConverter(new StringConverter<>() {
            @Override
            public String toString(LocalDate data) {
                return Formatos.data(data);
            }

            @Override
            public LocalDate fromString(String texto) {
                return texto == null || texto.isBlank() ? null : LocalDate.parse(texto, Formatos.DATA);
            }
        });

        try {
            cbCliente.setItems(FXCollections.observableArrayList(clienteDAO.listar()));
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
        // ao trocar o cliente, mostra apenas os equipamentos dele
        cbCliente.valueProperty().addListener((obs, antigo, cliente) -> carregarEquipamentos(cliente));

        lstHistorico.setCellFactory(lista -> new CelulaHistorico());
        lstHistorico.setPlaceholder(new Label("Sem histórico ainda."));
    }

    /** Chamado logo apos a tela ser carregada. */
    private void carregar(OrdemServico existente) {
        if (existente == null) {
            os = new OrdemServico();
            dpPrevisao.setValue(LocalDate.now().plusDays(3));
        } else {
            // recarrega do banco para garantir que os dados estao atualizados
            os = ordemDAO.buscarID(existente.getId());
            cbCliente.setValue(os.getCliente());
            cbEquipamento.setValue(os.getEquipamento());
            txtDefeito.setText(os.getDefeitoRelatado());
            txtDiagnostico.setText(os.getDiagnostico());
            txtServico.setText(os.getServicoExecutado());
            txtValor.setText(Formatos.valorEditavel(os.getValorOrcamento()));
            dpPrevisao.setValue(os.getDataPrevisao());
        }
        atualizarTela();
    }

    private void carregarEquipamentos(Cliente cliente) {
        List<Equipamento> lista = cliente == null ? List.of() : equipamentoDAO.listarPorCliente(cliente);
        cbEquipamento.setItems(FXCollections.observableArrayList(lista));
        cbEquipamento.setValue(lista.size() == 1 ? lista.get(0) : null);
        boolean semEquipamento = cliente != null && lista.isEmpty();
        lblSemEquipamento.setVisible(semEquipamento);
        lblSemEquipamento.setManaged(semEquipamento);
    }

    /** Ajusta titulo, status, campos habilitados e historico conforme a situacao da OS. */
    private void atualizarTela() {
        boolean nova = os.getId() == 0;
        boolean finalizada = os.getStatus().isFinal();

        lblTitulo.setText(nova ? "Nova ordem de serviço" : "OS " + os.getNumero());
        lblSubtitulo.setText(nova ? "Preencha os dados de entrada do equipamento"
                : os.getCliente().getNome() + " · " + os.getEquipamento().getDescricao());
        lblStatus.setText(os.getStatus().getDescricao());
        lblStatus.getStyleClass().setAll("label", "status", "status-grande", os.getStatus().getClasseCss());

        // cliente e equipamento so mudam enquanto a OS esta aberta
        boolean podeTrocarEquipamento = nova || os.getStatus() == StatusOS.ABERTA;
        cbCliente.setDisable(!podeTrocarEquipamento);
        cbEquipamento.setDisable(!podeTrocarEquipamento);
        for (var campo : List.of(txtDefeito, txtDiagnostico, txtServico)) campo.setEditable(!finalizada);
        txtValor.setEditable(!finalizada);
        dpPrevisao.setDisable(finalizada);
        btnSalvar.setDisable(finalizada);

        painelAndamento.setDisable(nova);
        cbProximoStatus.setItems(FXCollections.observableArrayList(os.getStatus().proximosStatus()));
        cbProximoStatus.setValue(null);
        txtObservacao.clear();
        boolean semProximo = os.getStatus().proximosStatus().isEmpty();
        cbProximoStatus.setDisable(semProximo);
        txtObservacao.setDisable(semProximo);
        btnAplicarStatus.setDisable(semProximo);
        lblDicaStatus.setText(nova ? "Salve a OS para acompanhar o andamento."
                : semProximo ? "Esta OS foi finalizada e não muda mais de status."
                : "Escolha a próxima etapa. As alterações dos campos ao lado são salvas junto.");

        lstHistorico.setItems(FXCollections.observableArrayList(
                nova ? List.of() : ordemDAO.listarHistorico(os.getId())));
        lstHistorico.scrollTo(lstHistorico.getItems().size() - 1);

        StringBuilder datas = new StringBuilder();
        if (!nova) datas.append("Aberta em ").append(Formatos.dataHora(os.getDataAbertura()));
        if (os.getDataConclusao() != null) datas.append("  ·  Concluída em ").append(Formatos.dataHora(os.getDataConclusao()));
        if (os.getDataEntrega() != null) datas.append("  ·  Entregue em ").append(Formatos.dataHora(os.getDataEntrega()));
        if (os.getTecnico() != null) datas.append("  ·  Técnico: ").append(os.getTecnico().getNome());
        lblDatas.setText(datas.toString());
    }

    /** Copia os campos da tela para o objeto OS. */
    private void lerFormulario() {
        os.setEquipamento(cbEquipamento.getValue());
        os.setDefeitoRelatado(textoOuNulo(txtDefeito.getText()));
        os.setDiagnostico(textoOuNulo(txtDiagnostico.getText()));
        os.setServicoExecutado(textoOuNulo(txtServico.getText()));
        os.setDataPrevisao(dpPrevisao.getValue());
        try {
            os.setValorOrcamento(Formatos.lerValor(txtValor.getText()));
        } catch (NumberFormatException e) {
            throw new RegraNegocioException("Valor do orçamento inválido. Use, por exemplo, 150,00.");
        }
    }

    @FXML
    private void btnSalvar_Click(ActionEvent event) {
        try {
            lerFormulario();
            if (os.getId() == 0) {
                ordemService.validarAbertura(os, LocalDate.now());
                os.setTecnico(Sessao.getUsuarioLogado());
                ordemDAO.insere(os);
                Alertas.info("OS " + os.getNumero() + " aberta com sucesso.");
            } else {
                ordemService.validarAlteracao(os);
                ordemDAO.alterar(os);
                Alertas.info("OS " + os.getNumero() + " salva.");
            }
            alterou = true;
            os = ordemDAO.buscarID(os.getId());
            atualizarTela();
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
    }

    @FXML
    private void btnAplicarStatus_Click(ActionEvent event) {
        StatusOS novo = cbProximoStatus.getValue();
        if (novo == null) {
            Alertas.aviso("Escolha para qual status a OS vai.");
            return;
        }
        if (novo == StatusOS.CANCELADA && !Alertas.confirmar("Cancelar a OS " + os.getNumero()
                + "? Essa ação não pode ser desfeita.")) {
            return;
        }

        StatusOS anterior = os.getStatus();
        try {
            lerFormulario();
            ordemService.validarAlteracao(os);
            ordemService.mudarStatus(os, novo, LocalDateTime.now().withNano(0));
        } catch (RegraNegocioException e) {
            // regra nao atendida: nada foi salvo e o que o usuario digitou continua na tela
            Alertas.aviso(e.getMessage());
            return;
        }

        try {
            ordemDAO.registrarMudancaStatus(os, anterior, Sessao.getUsuarioLogado(), txtObservacao.getText());
            alterou = true;
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
        // recarrega do banco: mostra o novo status (ou volta ao estado salvo, se deu erro)
        os = ordemDAO.buscarID(os.getId());
        atualizarTela();
    }

    @FXML
    private void btnFechar_Click(ActionEvent event) {
        ((Stage) btnSalvar.getScene().getWindow()).close();
    }

    private static String textoOuNulo(String texto) {
        return texto == null || texto.isBlank() ? null : texto.trim();
    }

    /** Item do historico: marcador azul, status em negrito e detalhes embaixo. */
    private static class CelulaHistorico extends ListCell<HistoricoStatus> {
        @Override
        protected void updateItem(HistoricoStatus h, boolean vazio) {
            super.updateItem(h, vazio);
            setText(null);
            if (vazio || h == null) {
                setGraphic(null);
                return;
            }
            Label status = new Label(h.getStatusNovo().getDescricao());
            status.getStyleClass().add("historico-status");

            StringBuilder detalhe = new StringBuilder(Formatos.dataHora(h.getDataHora()));
            if (h.getNomeUsuario() != null) detalhe.append(" · ").append(h.getNomeUsuario());
            Label quando = new Label(detalhe.toString());
            quando.getStyleClass().add("historico-detalhe");

            VBox textos = new VBox(1, status, quando);
            if (h.getObservacao() != null) {
                Label obs = new Label(h.getObservacao());
                obs.getStyleClass().add("historico-detalhe");
                obs.setWrapText(true);
                obs.setMaxWidth(250);
                textos.getChildren().add(obs);
            }
            Circle marcador = new Circle(5);
            marcador.getStyleClass().add("historico-marcador");
            HBox linha = new HBox(10, marcador, textos);
            linha.setAlignment(Pos.TOP_LEFT);
            HBox.setMargin(marcador, new Insets(5, 0, 0, 2));
            setGraphic(linha);
        }
    }
}
