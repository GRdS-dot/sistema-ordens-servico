package br.com.guilherme.assistencia.service;

import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import br.com.guilherme.assistencia.util.Validador;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Regras de negocio da ordem de servico.
 * <p>
 * Aqui fica o "o que pode e o que nao pode". O DAO so salva, e a tela so mostra.
 */
public class OrdemServicoService {

    /** Validacoes de uma OS que esta sendo aberta agora. */
    public void validarAbertura(OrdemServico os, LocalDate hoje) {
        List<String> erros = validarCampos(os);
        if (os.getDataPrevisao() != null && os.getDataPrevisao().isBefore(hoje)) {
            erros.add("A previsão de entrega não pode ser uma data passada.");
        }
        lancarSeHouverErros(erros);
    }

    /** Validacoes ao salvar alteracoes de uma OS ja existente. */
    public void validarAlteracao(OrdemServico os) {
        if (os.getStatus().isFinal()) {
            throw new RegraNegocioException("Uma OS " + os.getStatus().getDescricao().toLowerCase()
                    + " não pode mais ser alterada.");
        }
        lancarSeHouverErros(validarCampos(os));
    }

    /**
     * Muda o status da OS aplicando as regras de cada etapa.
     * Preenche as datas de conclusao/entrega automaticamente.
     *
     * @throws RegraNegocioException se a mudanca nao for permitida
     */
    public void mudarStatus(OrdemServico os, StatusOS novo, LocalDateTime agora) {
        StatusOS atual = os.getStatus();

        if (!atual.podeMudarPara(novo)) {
            throw new RegraNegocioException("Não é possível mudar de \"" + atual.getDescricao()
                    + "\" para \"" + (novo == null ? "?" : novo.getDescricao()) + "\".");
        }

        switch (novo) {
            case AGUARDANDO_APROVACAO -> {
                if (Validador.vazio(os.getDiagnostico())) {
                    throw new RegraNegocioException("Preencha o diagnóstico antes de enviar o orçamento ao cliente.");
                }
                if (os.getValorOrcamento() == null || os.getValorOrcamento().signum() <= 0) {
                    throw new RegraNegocioException("Informe o valor do orçamento antes de enviar ao cliente.");
                }
            }
            case PRONTA -> {
                if (Validador.vazio(os.getServicoExecutado())) {
                    throw new RegraNegocioException("Descreva o serviço executado antes de marcar a OS como pronta.");
                }
                os.setDataConclusao(agora);
            }
            case ENTREGUE -> os.setDataEntrega(agora);
            default -> {
                // demais etapas nao exigem nada alem da transicao valida
            }
        }

        os.setStatus(novo);
    }

    private List<String> validarCampos(OrdemServico os) {
        List<String> erros = new ArrayList<>();
        if (os.getEquipamento() == null) {
            erros.add("Selecione o cliente e o equipamento.");
        }
        if (Validador.vazio(os.getDefeitoRelatado())) {
            erros.add("Descreva o defeito relatado pelo cliente.");
        }
        BigDecimal valor = os.getValorOrcamento();
        if (valor != null && valor.signum() < 0) {
            erros.add("O valor do orçamento não pode ser negativo.");
        }
        return erros;
    }

    private void lancarSeHouverErros(List<String> erros) {
        if (!erros.isEmpty()) {
            throw new RegraNegocioException(String.join("\n", erros));
        }
    }
}
