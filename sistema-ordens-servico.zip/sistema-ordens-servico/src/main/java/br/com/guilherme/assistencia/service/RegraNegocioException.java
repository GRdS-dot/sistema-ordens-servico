package br.com.guilherme.assistencia.service;

/** Erro de regra de negocio: a mensagem e pensada para ser mostrada ao usuario. */
public class RegraNegocioException extends RuntimeException {

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
