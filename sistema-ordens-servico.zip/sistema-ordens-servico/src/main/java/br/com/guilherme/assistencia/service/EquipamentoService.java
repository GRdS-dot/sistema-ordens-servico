package br.com.guilherme.assistencia.service;

import br.com.guilherme.assistencia.model.Equipamento;
import br.com.guilherme.assistencia.util.Validador;

import java.util.ArrayList;
import java.util.List;

public class EquipamentoService {

    public void validar(Equipamento equipamento) {
        List<String> erros = new ArrayList<>();

        if (equipamento.getCliente() == null) {
            erros.add("Selecione o cliente dono do equipamento.");
        }
        if (equipamento.getTipo() == null) {
            erros.add("Selecione o tipo do equipamento.");
        }
        if (Validador.vazio(equipamento.getMarca())) {
            erros.add("Informe a marca do equipamento.");
        }

        if (!erros.isEmpty()) {
            throw new RegraNegocioException(String.join("\n", erros));
        }

        equipamento.setMarca(equipamento.getMarca().trim());
        equipamento.setModelo(limpar(equipamento.getModelo()));
        equipamento.setNumeroSerie(limpar(equipamento.getNumeroSerie()));
        equipamento.setObservacoes(limpar(equipamento.getObservacoes()));
    }

    private static String limpar(String texto) {
        return Validador.vazio(texto) ? null : texto.trim();
    }
}
