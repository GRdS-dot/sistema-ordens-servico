package br.com.guilherme.assistencia.util;

import java.util.regex.Pattern;

/** Validacoes e formatacoes de documentos e contatos. */
public final class Validador {

    private static final Pattern EMAIL =
            Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");

    private Validador() {
    }

    /** Remove tudo que nao for digito: "123.456.789-09" -> "12345678909". */
    public static String somenteDigitos(String texto) {
        return texto == null ? "" : texto.replaceAll("\\D", "");
    }

    public static boolean vazio(String texto) {
        return texto == null || texto.isBlank();
    }

    /**
     * Valida o CPF pelos dois digitos verificadores.
     * Rejeita sequencias repetidas como 111.111.111-11.
     */
    public static boolean cpfValido(String cpf) {
        String d = somenteDigitos(cpf);
        if (d.length() != 11 || d.chars().distinct().count() == 1) {
            return false;
        }
        return calcularDigito(d, 9) == d.charAt(9) - '0'
                && calcularDigito(d, 10) == d.charAt(10) - '0';
    }

    // Soma ponderada dos primeiros "tamanho" digitos (pesos decrescentes a partir de tamanho+1)
    private static int calcularDigito(String digitos, int tamanho) {
        int soma = 0;
        for (int i = 0; i < tamanho; i++) {
            soma += (digitos.charAt(i) - '0') * (tamanho + 1 - i);
        }
        int resto = (soma * 10) % 11;
        return resto == 10 ? 0 : resto;
    }

    /** Telefone fixo (10 digitos) ou celular (11 digitos), com DDD. */
    public static boolean telefoneValido(String telefone) {
        int tamanho = somenteDigitos(telefone).length();
        return tamanho == 10 || tamanho == 11;
    }

    public static boolean emailValido(String email) {
        return email != null && EMAIL.matcher(email.trim()).matches();
    }

    /** "12345678909" -> "123.456.789-09" */
    public static String formatarCpf(String cpf) {
        String d = somenteDigitos(cpf);
        if (d.length() != 11) return cpf == null ? "" : cpf;
        return d.substring(0, 3) + "." + d.substring(3, 6) + "." + d.substring(6, 9) + "-" + d.substring(9);
    }

    /** "11987654321" -> "(11) 98765-4321" ; "1144445555" -> "(11) 4444-5555" */
    public static String formatarTelefone(String telefone) {
        String d = somenteDigitos(telefone);
        if (d.length() == 11) {
            return "(" + d.substring(0, 2) + ") " + d.substring(2, 7) + "-" + d.substring(7);
        }
        if (d.length() == 10) {
            return "(" + d.substring(0, 2) + ") " + d.substring(2, 6) + "-" + d.substring(6);
        }
        return telefone == null ? "" : telefone;
    }
}
