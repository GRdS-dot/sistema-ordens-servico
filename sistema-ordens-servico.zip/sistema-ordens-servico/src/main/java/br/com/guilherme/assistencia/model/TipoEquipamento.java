package br.com.guilherme.assistencia.model;

public enum TipoEquipamento {

    NOTEBOOK("Notebook"),
    DESKTOP("Desktop"),
    CELULAR("Celular"),
    TABLET("Tablet"),
    IMPRESSORA("Impressora"),
    MONITOR("Monitor"),
    VIDEOGAME("Videogame"),
    OUTRO("Outro");

    private final String descricao;

    TipoEquipamento(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
