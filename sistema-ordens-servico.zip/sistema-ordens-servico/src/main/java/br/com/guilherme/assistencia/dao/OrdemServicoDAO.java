package br.com.guilherme.assistencia.dao;

import br.com.guilherme.assistencia.model.HistoricoStatus;
import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import br.com.guilherme.assistencia.model.Usuario;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Acesso as ordens de servico.
 * <p>
 * Toda mudanca de status grava tambem uma linha em historico_status.
 * As duas gravacoes acontecem na mesma transacao: ou salva tudo, ou nada.
 */
public class OrdemServicoDAO implements DAO<OrdemServico> {

    private static final String SELECT = "SELECT o.id, o.defeito_relatado, o.diagnostico, o.servico_executado, "
            + "o.status, o.valor_orcamento, o.data_abertura, o.data_previsao, o.data_conclusao, o.data_entrega, "
            + "u.id AS tec_id, u.nome AS tec_nome, u.login AS tec_login, "
            + EquipamentoDAO.COLUNAS + " "
            + "FROM ordem_servico o "
            + "JOIN equipamento e ON e.id = o.equipamento_id "
            + "JOIN cliente c ON c.id = e.cliente_id "
            + "LEFT JOIN usuario u ON u.id = o.tecnico_id ";

    /** Abre a OS (status ABERTA) e registra o primeiro item do historico. */
    @Override
    public void insere(OrdemServico os) {
        String sql = "INSERT INTO ordem_servico (equipamento_id, tecnico_id, defeito_relatado, diagnostico, "
                + "servico_executado, status, valor_orcamento, data_abertura, data_previsao, data_conclusao, "
                + "data_entrega) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        if (os.getDataAbertura() == null) {
            os.setDataAbertura(LocalDateTime.now().withNano(0));
        }
        try (Connection con = Banco.obterConexao()) {
            con.setAutoCommit(false);
            try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, os.getEquipamento().getId());
                JdbcUtil.setInteiro(ps, 2, os.getTecnico() == null ? null : os.getTecnico().getId());
                ps.setString(3, os.getDefeitoRelatado());
                JdbcUtil.setTexto(ps, 4, os.getDiagnostico());
                JdbcUtil.setTexto(ps, 5, os.getServicoExecutado());
                ps.setString(6, os.getStatus().name());
                setValor(ps, 7, os.getValorOrcamento());
                JdbcUtil.setDataHora(ps, 8, os.getDataAbertura());
                JdbcUtil.setData(ps, 9, os.getDataPrevisao());
                JdbcUtil.setDataHora(ps, 10, os.getDataConclusao());
                JdbcUtil.setDataHora(ps, 11, os.getDataEntrega());
                ps.executeUpdate();
                try (ResultSet chaves = ps.getGeneratedKeys()) {
                    if (chaves.next()) os.setId(chaves.getInt(1));
                }
                inserirHistorico(con, os.getId(), null, os.getStatus(), os.getTecnico(), "Abertura da OS",
                        os.getDataAbertura());
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "abrir a ordem de serviço");
        }
    }

    /** Salva os campos editaveis da OS (sem registrar historico). */
    @Override
    public void alterar(OrdemServico os) {
        try (Connection con = Banco.obterConexao()) {
            atualizar(con, os);
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "salvar a ordem de serviço");
        }
    }

    /**
     * Salva a OS com o novo status e registra a mudanca no historico, em uma unica transacao.
     *
     * @param anterior status antes da mudanca (a OS ja deve estar com o novo status)
     */
    public void registrarMudancaStatus(OrdemServico os, StatusOS anterior, Usuario usuario, String observacao) {
        try (Connection con = Banco.obterConexao()) {
            con.setAutoCommit(false);
            try {
                atualizar(con, os);
                inserirHistorico(con, os.getId(), anterior, os.getStatus(), usuario, observacao,
                        LocalDateTime.now().withNano(0));
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "mudar o status da ordem de serviço");
        }
    }

    @Override
    public void remover(int id) {
        // o historico e apagado junto (ON DELETE CASCADE)
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement("DELETE FROM ordem_servico WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "excluir a ordem de serviço");
        }
    }

    @Override
    public OrdemServico buscarID(int id) {
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(SELECT + "WHERE o.id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? montar(rs) : null;
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "buscar a ordem de serviço");
        }
    }

    @Override
    public List<OrdemServico> listar() {
        return pesquisar(null, false, "");
    }

    /**
     * Pesquisa as ordens de servico, das mais novas para as mais antigas.
     *
     * @param status         filtra por um status (null = todos)
     * @param somenteAbertas true = apenas as que ainda nao foram entregues nem canceladas
     * @param termo          numero da OS, nome do cliente, marca ou modelo do equipamento
     */
    public List<OrdemServico> pesquisar(StatusOS status, boolean somenteAbertas, String termo) {
        StringBuilder sql = new StringBuilder(SELECT)
                .append("WHERE (c.nome LIKE ? OR e.marca LIKE ? OR e.modelo LIKE ? OR o.id = ?) ");
        if (status != null) sql.append("AND o.status = ? ");
        if (somenteAbertas) sql.append("AND o.status NOT IN ('ENTREGUE', 'CANCELADA') ");
        sql.append("ORDER BY o.id DESC");

        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            String like = JdbcUtil.like(termo);
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            ps.setInt(4, numeroOuZero(termo));
            if (status != null) ps.setString(5, status.name());
            return listarResultado(ps);
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "listar as ordens de serviço");
        }
    }

    /** Ordens com previsao vencida que ainda nao ficaram prontas. */
    public List<OrdemServico> listarAtrasadas(LocalDate hoje) {
        String sql = SELECT + "WHERE o.data_previsao < ? "
                + "AND o.status NOT IN ('PRONTA', 'ENTREGUE', 'CANCELADA') ORDER BY o.data_previsao";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            JdbcUtil.setData(ps, 1, hoje);
            return listarResultado(ps);
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "listar as ordens atrasadas");
        }
    }

    /** Quantidade de OS em cada status (status sem nenhuma OS aparecem com zero). */
    public Map<StatusOS, Integer> contarPorStatus() {
        Map<StatusOS, Integer> contagem = new EnumMap<>(StatusOS.class);
        for (StatusOS s : StatusOS.values()) contagem.put(s, 0);

        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT status, COUNT(*) AS total FROM ordem_servico GROUP BY status");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                contagem.put(StatusOS.valueOf(rs.getString("status")), rs.getInt("total"));
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "contar as ordens de serviço");
        }
        return contagem;
    }

    /** Soma dos valores das OS entregues entre as datas (inclusive). */
    public BigDecimal faturamento(LocalDate inicio, LocalDate fim) {
        String sql = "SELECT COALESCE(SUM(valor_orcamento), 0) FROM ordem_servico "
                + "WHERE status = 'ENTREGUE' AND data_entrega >= ? AND data_entrega < ?";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            JdbcUtil.setData(ps, 1, inicio);
            JdbcUtil.setData(ps, 2, fim.plusDays(1));
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getBigDecimal(1);
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "calcular o faturamento");
        }
    }

    /** Quantidade de OS entregues entre as datas (inclusive). */
    public int contarEntregues(LocalDate inicio, LocalDate fim) {
        String sql = "SELECT COUNT(*) FROM ordem_servico "
                + "WHERE status = 'ENTREGUE' AND data_entrega >= ? AND data_entrega < ?";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            JdbcUtil.setData(ps, 1, inicio);
            JdbcUtil.setData(ps, 2, fim.plusDays(1));
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "contar as ordens entregues");
        }
    }

    public List<HistoricoStatus> listarHistorico(int ordemId) {
        String sql = "SELECT h.id, h.ordem_id, h.status_anterior, h.status_novo, h.data_hora, h.observacao, "
                + "u.nome AS usuario_nome FROM historico_status h "
                + "LEFT JOIN usuario u ON u.id = h.usuario_id WHERE h.ordem_id = ? ORDER BY h.data_hora, h.id";
        List<HistoricoStatus> lista = new ArrayList<>();
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, ordemId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    HistoricoStatus h = new HistoricoStatus();
                    h.setId(rs.getInt("id"));
                    h.setOrdemId(rs.getInt("ordem_id"));
                    String anterior = rs.getString("status_anterior");
                    h.setStatusAnterior(anterior == null ? null : StatusOS.valueOf(anterior));
                    h.setStatusNovo(StatusOS.valueOf(rs.getString("status_novo")));
                    h.setDataHora(JdbcUtil.getDataHora(rs, "data_hora"));
                    h.setNomeUsuario(rs.getString("usuario_nome"));
                    h.setObservacao(rs.getString("observacao"));
                    lista.add(h);
                }
            }
        } catch (SQLException e) {
            throw DAOException.traduzir(e, "carregar o histórico da OS");
        }
        return lista;
    }

    // ------------------------------------------------------------------ auxiliares

    private void atualizar(Connection con, OrdemServico os) throws SQLException {
        String sql = "UPDATE ordem_servico SET equipamento_id = ?, tecnico_id = ?, defeito_relatado = ?, "
                + "diagnostico = ?, servico_executado = ?, status = ?, valor_orcamento = ?, data_previsao = ?, "
                + "data_conclusao = ?, data_entrega = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, os.getEquipamento().getId());
            JdbcUtil.setInteiro(ps, 2, os.getTecnico() == null ? null : os.getTecnico().getId());
            ps.setString(3, os.getDefeitoRelatado());
            JdbcUtil.setTexto(ps, 4, os.getDiagnostico());
            JdbcUtil.setTexto(ps, 5, os.getServicoExecutado());
            ps.setString(6, os.getStatus().name());
            setValor(ps, 7, os.getValorOrcamento());
            JdbcUtil.setData(ps, 8, os.getDataPrevisao());
            JdbcUtil.setDataHora(ps, 9, os.getDataConclusao());
            JdbcUtil.setDataHora(ps, 10, os.getDataEntrega());
            ps.setInt(11, os.getId());
            ps.executeUpdate();
        }
    }

    private void inserirHistorico(Connection con, int ordemId, StatusOS anterior, StatusOS novo,
                                  Usuario usuario, String observacao, LocalDateTime dataHora) throws SQLException {
        String sql = "INSERT INTO historico_status (ordem_id, status_anterior, status_novo, data_hora, "
                + "usuario_id, observacao) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, ordemId);
            JdbcUtil.setTexto(ps, 2, anterior == null ? null : anterior.name());
            ps.setString(3, novo.name());
            JdbcUtil.setDataHora(ps, 4, dataHora);
            JdbcUtil.setInteiro(ps, 5, usuario == null ? null : usuario.getId());
            JdbcUtil.setTexto(ps, 6, observacao == null || observacao.isBlank() ? null : observacao.trim());
            ps.executeUpdate();
        }
    }

    private List<OrdemServico> listarResultado(PreparedStatement ps) throws SQLException {
        List<OrdemServico> lista = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(montar(rs));
        }
        return lista;
    }

    private static void setValor(PreparedStatement ps, int indice, BigDecimal valor) throws SQLException {
        if (valor == null) ps.setNull(indice, Types.DECIMAL);
        else ps.setBigDecimal(indice, valor);
    }

    /** "123" ou "000123" -> 123; texto que nao e numero -> 0 (nenhuma OS tem id 0). */
    private static int numeroOuZero(String termo) {
        if (termo == null) return 0;
        String t = termo.trim();
        if (t.isEmpty() || t.length() > 9 || !t.chars().allMatch(Character::isDigit)) return 0;
        return Integer.parseInt(t);
    }

    private static OrdemServico montar(ResultSet rs) throws SQLException {
        OrdemServico os = new OrdemServico();
        os.setId(rs.getInt("id"));
        os.setEquipamento(EquipamentoDAO.montar(rs));
        os.setDefeitoRelatado(rs.getString("defeito_relatado"));
        os.setDiagnostico(rs.getString("diagnostico"));
        os.setServicoExecutado(rs.getString("servico_executado"));
        os.setStatus(StatusOS.valueOf(rs.getString("status")));
        os.setValorOrcamento(rs.getBigDecimal("valor_orcamento"));
        os.setDataAbertura(JdbcUtil.getDataHora(rs, "data_abertura"));
        os.setDataPrevisao(JdbcUtil.getData(rs, "data_previsao"));
        os.setDataConclusao(JdbcUtil.getDataHora(rs, "data_conclusao"));
        os.setDataEntrega(JdbcUtil.getDataHora(rs, "data_entrega"));

        int tecnicoId = rs.getInt("tec_id");
        if (!rs.wasNull()) {
            os.setTecnico(new Usuario(tecnicoId, rs.getString("tec_nome"), rs.getString("tec_login")));
        }
        return os;
    }
}
