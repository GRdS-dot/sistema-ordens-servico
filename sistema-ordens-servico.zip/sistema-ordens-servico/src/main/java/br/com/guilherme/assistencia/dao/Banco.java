package br.com.guilherme.assistencia.dao;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Fornece conexoes com o MySQL.
 * <p>
 * A configuracao e lida, nesta ordem de prioridade:
 * <ol>
 *     <li>variaveis de ambiente DB_URL, DB_USER e DB_PASSWORD (usadas nos testes automaticos);</li>
 *     <li>arquivo {@code banco.properties} na pasta onde o sistema e executado;</li>
 *     <li>valores padrao embutidos em {@code src/main/resources/banco.properties}.</li>
 * </ol>
 * Assim a senha do banco nao fica escrita no codigo.
 */
public final class Banco {

    private static final String ARQUIVO = "banco.properties";
    private static Properties config;

    private Banco() {
    }

    /**
     * Abre uma nova conexao. Quem chama deve fechar (use try-with-resources):
     * <pre>
     * try (Connection con = Banco.obterConexao()) { ... }
     * </pre>
     */
    public static Connection obterConexao() throws SQLException {
        Properties c = configuracao();
        return DriverManager.getConnection(c.getProperty("url"), c.getProperty("usuario"), c.getProperty("senha"));
    }

    /** @return null se conectou, ou a mensagem do erro */
    public static String testarConexao() {
        try (Connection con = obterConexao()) {
            return con.isValid(3) ? null : "Conexão inválida.";
        } catch (SQLException e) {
            return e.getMessage();
        }
    }

    public static String getUrl() {
        return configuracao().getProperty("url");
    }

    private static synchronized Properties configuracao() {
        if (config == null) {
            config = carregar();
        }
        return config;
    }

    private static Properties carregar() {
        Properties p = new Properties();

        try (InputStream padrao = Banco.class.getResourceAsStream("/" + ARQUIVO)) {
            if (padrao != null) p.load(padrao);
        } catch (IOException e) {
            throw new IllegalStateException("Não foi possível ler a configuração padrão do banco", e);
        }

        Path local = Path.of(ARQUIVO);
        if (Files.exists(local)) {
            try (Reader r = Files.newBufferedReader(local, StandardCharsets.UTF_8)) {
                p.load(r);
            } catch (IOException e) {
                throw new IllegalStateException("Não foi possível ler " + local.toAbsolutePath(), e);
            }
        }

        sobrescrever(p, "url", System.getenv("DB_URL"));
        sobrescrever(p, "usuario", System.getenv("DB_USER"));
        sobrescrever(p, "senha", System.getenv("DB_PASSWORD"));
        return p;
    }

    private static void sobrescrever(Properties p, String chave, String valor) {
        if (valor != null) p.setProperty(chave, valor);
    }
}
