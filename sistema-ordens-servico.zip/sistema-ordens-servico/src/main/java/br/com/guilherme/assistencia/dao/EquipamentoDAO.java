package br.com.guilherme.assistencia.dao;

import br.com.guilherme.assistencia.model.Cliente;
import br.com.guilherme.assistencia.model.Equipamento;
import br.com.guilherme.assistencia.model.TipoEquipamento;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EquipamentoDAO implements DAO<Equipamento> {

    /** Colunas do equipamento e do seu dono (reaproveitadas pelo OrdemServicoDAO). */
    static final String COLUNAS = "e.id AS eq_id, e.tipo AS eq_tipo, e.marca AS eq_marca, e.modelo AS eq_modelo, "
            + "e.numero_serie AS eq_numero_serie, e.observacoes AS eq_observacoes, "
            + "c.id AS cli_id, c.nome AS cli_nome, c.cpf AS cli_cpf, c.telefone AS cli_telefone, "
            + "c.email AS cli_email, c.endereco AS cli_endereco";

    // JOIN com cliente para ja trazer o dono do equipamento
    private static final String SELECT = "SELECT " + COLUNAS
            + " FROM equipamento e JOIN cliente c ON c.id = e.cliente_id ";

    @Override
    public void insere(Equipamento e) {
        String sql = "INSERT INTO equipamento (cliente_id, tipo, marca, modelo, numero_serie, observacoes) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preencher(ps, e);
            ps.executeUpdate();
            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) e.setId(chaves.getInt(1));
            }
        } catch (SQLException ex) {
            throw DAOException.traduzir(ex, "salvar o equipamento");
        }
    }

    @Override
    public void alterar(Equipamento e) {
        String sql = "UPDATE equipamento SET cliente_id = ?, tipo = ?, marca = ?, modelo = ?, "
                + "numero_serie = ?, observacoes = ? WHERE id = ?";
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            preencher(ps, e);
            ps.setInt(7, e.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw DAOException.traduzir(ex, "alterar o equipamento");
        }
    }

    @Override
    public void remover(int id) {
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement("DELETE FROM equipamento WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw DAOException.traduzir(ex, "excluir o equipamento",
                    "Este equipamento possui ordens de serviço e não pode ser excluído.");
        }
    }

    @Override
    public Equipamento buscarID(int id) {
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(SELECT + "WHERE e.id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? montar(rs) : null;
            }
        } catch (SQLException ex) {
            throw DAOException.traduzir(ex, "buscar o equipamento");
        }
    }

    @Override
    public List<Equipamento> listar() {
        return pesquisar(null, "");
    }

    public List<Equipamento> listarPorCliente(Cliente cliente) {
        return pesquisar(cliente, "");
    }

    /**
     * @param cliente filtra pelo dono (null = todos)
     * @param termo   parte da marca, modelo, numero de serie ou nome do cliente
     */
    public List<Equipamento> pesquisar(Cliente cliente, String termo) {
        String sql = SELECT
                + "WHERE (? = 0 OR e.cliente_id = ?) "
                + "AND (e.marca LIKE ? OR e.modelo LIKE ? OR e.numero_serie LIKE ? OR c.nome LIKE ?) "
                + "ORDER BY c.nome, e.marca, e.modelo";
        List<Equipamento> lista = new ArrayList<>();
        try (Connection con = Banco.obterConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            int idCliente = cliente == null ? 0 : cliente.getId();
            String like = JdbcUtil.like(termo);
            ps.setInt(1, idCliente);
            ps.setInt(2, idCliente);
            for (int i = 3; i <= 6; i++) ps.setString(i, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(montar(rs));
            }
        } catch (SQLException ex) {
            throw DAOException.traduzir(ex, "listar os equipamentos");
        }
        return lista;
    }

    private void preencher(PreparedStatement ps, Equipamento e) throws SQLException {
        ps.setInt(1, e.getCliente().getId());
        ps.setString(2, e.getTipo().name());
        ps.setString(3, e.getMarca());
        JdbcUtil.setTexto(ps, 4, e.getModelo());
        JdbcUtil.setTexto(ps, 5, e.getNumeroSerie());
        JdbcUtil.setTexto(ps, 6, e.getObservacoes());
    }

    /** Monta o equipamento (e o cliente) a partir de uma linha do SELECT acima. */
    static Equipamento montar(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setId(rs.getInt("cli_id"));
        c.setNome(rs.getString("cli_nome"));
        c.setCpf(rs.getString("cli_cpf"));
        c.setTelefone(rs.getString("cli_telefone"));
        c.setEmail(rs.getString("cli_email"));
        c.setEndereco(rs.getString("cli_endereco"));

        Equipamento e = new Equipamento();
        e.setId(rs.getInt("eq_id"));
        e.setCliente(c);
        e.setTipo(TipoEquipamento.valueOf(rs.getString("eq_tipo")));
        e.setMarca(rs.getString("eq_marca"));
        e.setModelo(rs.getString("eq_modelo"));
        e.setNumeroSerie(rs.getString("eq_numero_serie"));
        e.setObservacoes(rs.getString("eq_observacoes"));
        return e;
    }
}
