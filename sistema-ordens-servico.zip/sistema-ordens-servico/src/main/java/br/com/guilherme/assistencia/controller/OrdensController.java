package br.com.guilherme.assistencia.controller;

import br.com.guilherme.assistencia.dao.OrdemServicoDAO;
import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import br.com.guilherme.assistencia.util.Alertas;
import br.com.guilherme.assistencia.util.Formatos;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

/** Lista de ordens de servico com filtro por status e busca. */
public class OrdensController implements Initializable {

    private static final String EM_ANDAMENTO = "Em andamento";
    private static final String TODAS = "Todas as ordens";

    @FXML
    private Label lblTotal;
    @FXML
    private ComboBox<String> cbFiltroStatus;
    @FXML
    private TextField txtPesquisa;
    @FXML
    private TableView<OrdemServico> tblOrdens;
    @FXML
    private TableColumn<OrdemServico, String> colNumero;
    @FXML
    private TableColumn<OrdemServico, String> colCliente;
    @FXML
    private TableColumn<OrdemServico, String> colEquipamento;
    @FXML
    private TableColumn<OrdemServico, StatusOS> colStatus;
    @FXML
    private TableColumn<OrdemServico, String> colAbertura;
    @FXML
    private TableColumn<OrdemServico, String> colPrevisao;
    @FXML
    private TableColumn<OrdemServico, String> colValor;

    private final OrdemServicoDAO ordemDAO = new OrdemServicoDAO();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        LocalDate hoje = LocalDate.now();
        Tabelas.texto(colNumero, OrdemServico::getNumero);
        Tabelas.texto(colCliente, os -> os.getCliente().getNome());
        Tabelas.texto(colEquipamento, os -> os.getEquipamento().getDescricao());
        Tabelas.status(colStatus, OrdemServico::getStatus);
        Tabelas.texto(colAbertura, os -> Formatos.data(os.getDataAbertura()));
        Tabelas.texto(colPrevisao, os -> Formatos.data(os.getDataPrevisao()));
        Tabelas.destacarAtraso(colPrevisao, hoje);
        Tabelas.texto(colValor, os -> Formatos.moeda(os.getValorOrcamento()));
        Tabelas.duploClique(tblOrdens, this::abrir);
        Tabelas.colunaFlexivel(tblOrdens, colEquipamento);
        tblOrdens.setPlaceholder(new Label("Nenhuma ordem de serviço encontrada."));

        ObservableList<String> filtros = FXCollections.observableArrayList(EM_ANDAMENTO, TODAS);
        for (StatusOS s : StatusOS.values()) filtros.add(s.getDescricao());
        cbFiltroStatus.setItems(filtros);
        cbFiltroStatus.setValue(EM_ANDAMENTO);

        cbFiltroStatus.valueProperty().addListener((obs, antigo, novo) -> carregar());
        txtPesquisa.textProperty().addListener((obs, antigo, novo) -> carregar());
        carregar();
    }

    private void carregar() {
        String filtro = cbFiltroStatus.getValue();
        StatusOS status = null;
        for (StatusOS s : StatusOS.values()) {
            if (s.getDescricao().equals(filtro)) status = s;
        }
        try {
            List<OrdemServico> ordens = ordemDAO.pesquisar(status, EM_ANDAMENTO.equals(filtro), txtPesquisa.getText());
            tblOrdens.setItems(FXCollections.observableArrayList(ordens));
            lblTotal.setText(ordens.size() == 1 ? "1 ordem" : ordens.size() + " ordens");
        } catch (RuntimeException e) {
            Alertas.erro(e);
        }
    }

    private void abrir(OrdemServico os) {
        if (OrdemFormController.abrir(os)) carregar();
    }

    @FXML
    private void btnNova_Click(ActionEvent event) {
        if (OrdemFormController.abrir(null)) carregar();
    }

    @FXML
    private void btnAbrir_Click(ActionEvent event) {
        OrdemServico os = tblOrdens.getSelectionModel().getSelectedItem();
        if (os == null) {
            Alertas.aviso("Selecione uma ordem de serviço na lista.");
            return;
        }
        abrir(os);
    }
}
