package br.com.guilherme.assistencia.dao;

import java.util.List;

/**
 * Contrato basico de acesso a dados (padrao DAO).
 * Cada entidade tem sua implementacao com o SQL correspondente.
 *
 * @param <T> tipo da entidade
 */
public interface DAO<T> {

    /** Insere o objeto e preenche o id gerado pelo banco. */
    void insere(T obj);

    void alterar(T obj);

    void remover(int id);

    /** @return o objeto ou null se nao existir */
    T buscarID(int id);

    List<T> listar();
}
