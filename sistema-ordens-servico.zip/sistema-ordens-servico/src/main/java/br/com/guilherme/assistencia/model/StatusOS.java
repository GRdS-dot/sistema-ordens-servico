package br.com.guilherme.assistencia.model;

import java.util.EnumSet;
import java.util.Set;

/**
 * Etapas pelas quais uma ordem de servico passa.
 * <p>
 * Cada status sabe para quais outros ele pode avancar. Assim a regra do
 * fluxo fica em um lugar so, e a tela apenas oferece as opcoes validas.
 *
 * <pre>
 * ABERTA -> EM_ANALISE -> AGUARDANDO_APROVACAO -> EM_REPARO -> PRONTA -> ENTREGUE
 *                                                  ^      |
 *                                                  |      v
 *                                             AGUARDANDO_PECA
 * (ate o reparo comecar, a OS pode ser CANCELADA)
 * </pre>
 */
public enum StatusOS {

    ABERTA("Aberta"),
    EM_ANALISE("Em análise"),
    AGUARDANDO_APROVACAO("Aguardando aprovação"),
    EM_REPARO("Em reparo"),
    AGUARDANDO_PECA("Aguardando peça"),
    PRONTA("Pronta para retirada"),
    ENTREGUE("Entregue"),
    CANCELADA("Cancelada");

    private final String descricao;

    StatusOS(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    /** Status para os quais a OS pode ir a partir deste. */
    public Set<StatusOS> proximosStatus() {
        return switch (this) {
            case ABERTA -> EnumSet.of(EM_ANALISE, CANCELADA);
            case EM_ANALISE -> EnumSet.of(AGUARDANDO_APROVACAO, CANCELADA);
            case AGUARDANDO_APROVACAO -> EnumSet.of(EM_REPARO, CANCELADA);
            case EM_REPARO -> EnumSet.of(AGUARDANDO_PECA, PRONTA);
            case AGUARDANDO_PECA -> EnumSet.of(EM_REPARO);
            case PRONTA -> EnumSet.of(ENTREGUE);
            case ENTREGUE, CANCELADA -> EnumSet.noneOf(StatusOS.class);
        };
    }

    public boolean podeMudarPara(StatusOS novo) {
        return novo != null && proximosStatus().contains(novo);
    }

    /** Uma OS finalizada nao muda mais de status. */
    public boolean isFinal() {
        return this == ENTREGUE || this == CANCELADA;
    }

    /** Classe CSS usada para colorir o status nas telas. */
    public String getClasseCss() {
        return "status-" + name().toLowerCase().replace('_', '-');
    }

    @Override
    public String toString() {
        return descricao;
    }
}
