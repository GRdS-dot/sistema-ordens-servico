package br.com.guilherme.assistencia.model;

import java.time.LocalDateTime;

/** Registro de uma mudanca de status da OS (quem mudou, quando e por que). */
public class HistoricoStatus {

    private int id;
    private int ordemId;
    private StatusOS statusAnterior;
    private StatusOS statusNovo;
    private LocalDateTime dataHora;
    private String nomeUsuario;
    private String observacao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOrdemId() {
        return ordemId;
    }

    public void setOrdemId(int ordemId) {
        this.ordemId = ordemId;
    }

    public StatusOS getStatusAnterior() {
        return statusAnterior;
    }

    public void setStatusAnterior(StatusOS statusAnterior) {
        this.statusAnterior = statusAnterior;
    }

    public StatusOS getStatusNovo() {
        return statusNovo;
    }

    public void setStatusNovo(StatusOS statusNovo) {
        this.statusNovo = statusNovo;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}
