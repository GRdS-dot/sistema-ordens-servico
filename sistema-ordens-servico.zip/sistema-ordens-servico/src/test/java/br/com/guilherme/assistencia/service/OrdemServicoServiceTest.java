package br.com.guilherme.assistencia.service;

import br.com.guilherme.assistencia.model.Cliente;
import br.com.guilherme.assistencia.model.Equipamento;
import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import br.com.guilherme.assistencia.model.TipoEquipamento;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class OrdemServicoServiceTest {

    private static final LocalDate HOJE = LocalDate.of(2026, 11, 6);
    private static final LocalDateTime AGORA = LocalDateTime.of(2026, 11, 6, 14, 30);

    private final OrdemServicoService service = new OrdemServicoService();
    private OrdemServico os;

    @BeforeEach
    void criarOrdem() {
        Cliente cliente = new Cliente("Maria Silva", null, "11987654321", null, null);
        cliente.setId(1);
        Equipamento notebook = new Equipamento(cliente, TipoEquipamento.NOTEBOOK, "Dell", "Inspiron 15");
        notebook.setId(1);

        os = new OrdemServico();
        os.setId(10);
        os.setEquipamento(notebook);
        os.setDefeitoRelatado("Não liga");
    }

    @Test
    void abreOrdemValida() {
        os.setDataPrevisao(HOJE.plusDays(3));
        assertDoesNotThrow(() -> service.validarAbertura(os, HOJE));
    }

    @Test
    void exigeEquipamentoEDefeitoNaAbertura() {
        os.setEquipamento(null);
        os.setDefeitoRelatado("  ");
        RegraNegocioException erro = assertThrows(RegraNegocioException.class,
                () -> service.validarAbertura(os, HOJE));
        assertTrue(erro.getMessage().contains("equipamento"));
        assertTrue(erro.getMessage().contains("defeito"));
    }

    @Test
    void naoAceitaPrevisaoNoPassado() {
        os.setDataPrevisao(HOJE.minusDays(1));
        assertThrows(RegraNegocioException.class, () -> service.validarAbertura(os, HOJE));
    }

    @Test
    void naoAceitaValorNegativo() {
        os.setValorOrcamento(new BigDecimal("-10"));
        assertThrows(RegraNegocioException.class, () -> service.validarAbertura(os, HOJE));
    }

    @Test
    void naoPermiteMudancaForaDoFluxo() {
        RegraNegocioException erro = assertThrows(RegraNegocioException.class,
                () -> service.mudarStatus(os, StatusOS.ENTREGUE, AGORA));
        assertTrue(erro.getMessage().contains("Aberta"));
        assertEquals(StatusOS.ABERTA, os.getStatus());
    }

    @Test
    void orcamentoExigeDiagnosticoEValor() {
        os.setStatus(StatusOS.EM_ANALISE);

        assertThrows(RegraNegocioException.class,
                () -> service.mudarStatus(os, StatusOS.AGUARDANDO_APROVACAO, AGORA));

        os.setDiagnostico("Conector de carga danificado");
        assertThrows(RegraNegocioException.class,
                () -> service.mudarStatus(os, StatusOS.AGUARDANDO_APROVACAO, AGORA));

        os.setValorOrcamento(new BigDecimal("180.00"));
        service.mudarStatus(os, StatusOS.AGUARDANDO_APROVACAO, AGORA);
        assertEquals(StatusOS.AGUARDANDO_APROVACAO, os.getStatus());
    }

    @Test
    void marcarComoProntaExigeServicoERegistraConclusao() {
        os.setStatus(StatusOS.EM_REPARO);

        assertThrows(RegraNegocioException.class, () -> service.mudarStatus(os, StatusOS.PRONTA, AGORA));
        assertNull(os.getDataConclusao());

        os.setServicoExecutado("Troca do conector DC");
        service.mudarStatus(os, StatusOS.PRONTA, AGORA);
        assertEquals(StatusOS.PRONTA, os.getStatus());
        assertEquals(AGORA, os.getDataConclusao());
    }

    @Test
    void entregaRegistraDataDeEntrega() {
        os.setStatus(StatusOS.PRONTA);
        service.mudarStatus(os, StatusOS.ENTREGUE, AGORA);
        assertEquals(AGORA, os.getDataEntrega());
        assertTrue(os.getStatus().isFinal());
    }

    @Test
    void ordemFinalizadaNaoPodeSerAlterada() {
        os.setStatus(StatusOS.ENTREGUE);
        assertThrows(RegraNegocioException.class, () -> service.validarAlteracao(os));
    }

    @Test
    void ordemAtrasadaQuandoPassaDaPrevisao() {
        os.setDataPrevisao(HOJE.minusDays(2));
        assertTrue(os.isAtrasada(HOJE));

        os.setStatus(StatusOS.PRONTA);           // ja esta pronta: nao conta como atraso
        assertFalse(os.isAtrasada(HOJE));
    }
}
