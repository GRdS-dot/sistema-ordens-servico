package br.com.guilherme.assistencia.service;

import br.com.guilherme.assistencia.model.Cliente;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClienteServiceTest {

    private final ClienteService service = new ClienteService();

    @Test
    void normalizaCpfTelefoneECamposVazios() {
        Cliente c = new Cliente("  Maria Silva ", "529.982.247-25", "(11) 98765-4321", "", "   ");

        service.validar(c);

        assertEquals("Maria Silva", c.getNome());
        assertEquals("52998224725", c.getCpf());
        assertEquals("11987654321", c.getTelefone());
        assertNull(c.getEmail());
        assertNull(c.getEndereco());
    }

    @Test
    void cpfEOpcional() {
        Cliente c = new Cliente("Empresa XYZ", "", "1144445555", null, null);
        service.validar(c);
        assertNull(c.getCpf());
    }

    @Test
    void juntaTodosOsErrosEmUmaMensagem() {
        Cliente c = new Cliente("Jo", "111.111.111-11", "1234", "email-invalido", null);

        RegraNegocioException erro = assertThrows(RegraNegocioException.class, () -> service.validar(c));

        String msg = erro.getMessage();
        assertTrue(msg.contains("nome"));
        assertTrue(msg.contains("telefone"));
        assertTrue(msg.contains("CPF"));
        assertTrue(msg.contains("E-mail"));
        assertEquals(4, msg.split("\n").length);
    }
}
