package br.com.guilherme.assistencia.dao;

import br.com.guilherme.assistencia.model.Cliente;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClienteDAOTest {

    private final ClienteDAO dao = new ClienteDAO();
    private final List<Integer> criados = new ArrayList<>();

    @BeforeEach
    void verificarBanco() {
        BancoDisponivel.exigir();
    }

    @AfterEach
    void limpar() {
        criados.forEach(dao::remover);
    }

    private Cliente novoCliente(String nome, String cpf) {
        Cliente c = new Cliente(nome, cpf, "11999990000", "teste@exemplo.com", "Rua de Teste, 1");
        dao.insere(c);
        criados.add(c.getId());
        return c;
    }

    @Test
    void insereEBuscaPorId() {
        Cliente c = novoCliente("Cliente Teste DAO", null);

        assertTrue(c.getId() > 0);
        Cliente doBanco = dao.buscarID(c.getId());
        assertNotNull(doBanco);
        assertEquals("Cliente Teste DAO", doBanco.getNome());
        assertNotNull(doBanco.getDataCadastro());
    }

    @Test
    void alteraOsDados() {
        Cliente c = novoCliente("Nome Antigo Teste", null);
        c.setNome("Nome Novo Teste");
        c.setTelefone("11888887777");
        dao.alterar(c);

        Cliente doBanco = dao.buscarID(c.getId());
        assertEquals("Nome Novo Teste", doBanco.getNome());
        assertEquals("11888887777", doBanco.getTelefone());
    }

    @Test
    void pesquisaPorParteDoNome() {
        novoCliente("Zuleica Pesquisa Teste", null);
        List<Cliente> achados = dao.pesquisar("zuleica pesq");
        assertEquals(1, achados.size());
    }

    @Test
    void naoPermiteCpfDuplicado() {
        novoCliente("Primeiro Teste", "11144477735");
        DAOException erro = assertThrows(DAOException.class, () -> novoCliente("Segundo Teste", "11144477735"));
        assertTrue(erro.getMessage().contains("CPF"));
    }

    @Test
    void remove() {
        Cliente c = novoCliente("Para Remover Teste", null);
        dao.remover(c.getId());
        criados.remove(Integer.valueOf(c.getId()));
        assertNull(dao.buscarID(c.getId()));
    }
}
