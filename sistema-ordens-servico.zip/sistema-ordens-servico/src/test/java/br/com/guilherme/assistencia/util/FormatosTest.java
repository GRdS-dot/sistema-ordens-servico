package br.com.guilherme.assistencia.util;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

class FormatosTest {

    @Test
    void leValoresDigitadosNoPadraoBrasileiro() {
        assertEquals(new BigDecimal("150.00"), Formatos.lerValor("150"));
        assertEquals(new BigDecimal("150.90"), Formatos.lerValor("150,90"));
        assertEquals(new BigDecimal("1250.00"), Formatos.lerValor("1.250,00"));
        assertEquals(new BigDecimal("80.00"), Formatos.lerValor("R$ 80"));
        assertNull(Formatos.lerValor("  "));
    }

    @Test
    void textoInvalidoGeraErro() {
        assertThrows(NumberFormatException.class, () -> Formatos.lerValor("cem reais"));
    }

    @Test
    void formataMoeda() {
        assertEquals("R$ 1.250,50", Formatos.moeda(new BigDecimal("1250.5")));
    }
}
