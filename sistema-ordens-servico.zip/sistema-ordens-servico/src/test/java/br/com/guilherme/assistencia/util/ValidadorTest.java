package br.com.guilherme.assistencia.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ValidadorTest {

    @ParameterizedTest
    @ValueSource(strings = {"529.982.247-25", "52998224725", "111.444.777-35"})
    void aceitaCpfValido(String cpf) {
        assertTrue(Validador.cpfValido(cpf));
    }

    @ParameterizedTest
    @ValueSource(strings = {"529.982.247-24", "111.111.111-11", "123", "", "abc.def.ghi-jk"})
    void rejeitaCpfInvalido(String cpf) {
        assertFalse(Validador.cpfValido(cpf));
    }

    @Test
    void rejeitaCpfNulo() {
        assertFalse(Validador.cpfValido(null));
    }

    @Test
    void validaTelefoneComDdd() {
        assertTrue(Validador.telefoneValido("(11) 98765-4321"));
        assertTrue(Validador.telefoneValido("1144445555"));
        assertFalse(Validador.telefoneValido("98765-4321"));
    }

    @Test
    void validaEmail() {
        assertTrue(Validador.emailValido("guilherme@exemplo.com.br"));
        assertFalse(Validador.emailValido("guilherme@"));
        assertFalse(Validador.emailValido("sem arroba.com"));
    }

    @Test
    void formataCpfETelefone() {
        assertEquals("529.982.247-25", Validador.formatarCpf("52998224725"));
        assertEquals("(11) 98765-4321", Validador.formatarTelefone("11987654321"));
        assertEquals("(11) 4444-5555", Validador.formatarTelefone("1144445555"));
    }
}
