package br.com.guilherme.assistencia.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SenhaTest {

    @Test
    void confereASenhaCorreta() {
        String hash = Senha.gerarHash("minhaSenha123");
        assertTrue(Senha.conferir("minhaSenha123", hash));
        assertFalse(Senha.conferir("minhasenha123", hash));
    }

    @Test
    void mesmaSenhaGeraHashesDiferentes() {
        // por causa do salt aleatorio
        assertNotEquals(Senha.gerarHash("admin123"), Senha.gerarHash("admin123"));
    }

    @Test
    void naoGuardaASenhaNoHash() {
        assertFalse(Senha.gerarHash("admin123").contains("admin123"));
    }

    @Test
    void hashMalformadoNaoPassa() {
        assertFalse(Senha.conferir("admin123", "texto-qualquer"));
        assertFalse(Senha.conferir("admin123", null));
    }
}
