package br.com.guilherme.assistencia.dao;

import br.com.guilherme.assistencia.model.Cliente;
import br.com.guilherme.assistencia.model.Equipamento;
import br.com.guilherme.assistencia.model.HistoricoStatus;
import br.com.guilherme.assistencia.model.OrdemServico;
import br.com.guilherme.assistencia.model.StatusOS;
import br.com.guilherme.assistencia.model.TipoEquipamento;
import br.com.guilherme.assistencia.model.Usuario;
import br.com.guilherme.assistencia.service.OrdemServicoService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class OrdemServicoDAOTest {

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final EquipamentoDAO equipamentoDAO = new EquipamentoDAO();
    private final OrdemServicoDAO dao = new OrdemServicoDAO();
    private final OrdemServicoService service = new OrdemServicoService();
    private final Usuario admin = new Usuario(1, "Administrador", "admin");

    private Cliente cliente;
    private Equipamento equipamento;
    private OrdemServico os;

    @BeforeEach
    void preparar() {
        BancoDisponivel.exigir();

        cliente = new Cliente("Cliente OS Teste", null, "11977776666", null, null);
        clienteDAO.insere(cliente);

        equipamento = new Equipamento(cliente, TipoEquipamento.NOTEBOOK, "MarcaTesteXYZ", "Modelo 1");
        equipamentoDAO.insere(equipamento);

        os = new OrdemServico();
        os.setEquipamento(equipamento);
        os.setTecnico(admin);
        os.setDefeitoRelatado("Não liga");
        os.setDataPrevisao(LocalDate.now().plusDays(2));
        dao.insere(os);
    }

    @AfterEach
    void limpar() {
        if (os != null && os.getId() > 0) dao.remover(os.getId());
        if (equipamento != null && equipamento.getId() > 0) equipamentoDAO.remover(equipamento.getId());
        if (cliente != null && cliente.getId() > 0) clienteDAO.remover(cliente.getId());
    }

    @Test
    void abrirOsCriaPrimeiroRegistroNoHistorico() {
        OrdemServico doBanco = dao.buscarID(os.getId());
        assertEquals(StatusOS.ABERTA, doBanco.getStatus());
        assertEquals("Cliente OS Teste", doBanco.getCliente().getNome());
        assertEquals("Administrador", doBanco.getTecnico().getNome());
        assertNotNull(doBanco.getDataAbertura());

        List<HistoricoStatus> historico = dao.listarHistorico(os.getId());
        assertEquals(1, historico.size());
        assertNull(historico.get(0).getStatusAnterior());
        assertEquals(StatusOS.ABERTA, historico.get(0).getStatusNovo());
    }

    @Test
    void fluxoCompletoAteEntregaFicaNoHistorico() {
        avancar(StatusOS.EM_ANALISE);
        os.setDiagnostico("Conector DC danificado");
        os.setValorOrcamento(new BigDecimal("180.00"));
        avancar(StatusOS.AGUARDANDO_APROVACAO);
        avancar(StatusOS.EM_REPARO);
        os.setServicoExecutado("Troca do conector DC");
        avancar(StatusOS.PRONTA);
        avancar(StatusOS.ENTREGUE);

        OrdemServico doBanco = dao.buscarID(os.getId());
        assertEquals(StatusOS.ENTREGUE, doBanco.getStatus());
        assertEquals(0, new BigDecimal("180.00").compareTo(doBanco.getValorOrcamento()));
        assertNotNull(doBanco.getDataConclusao());
        assertNotNull(doBanco.getDataEntrega());
        assertEquals(6, dao.listarHistorico(os.getId()).size());

        BigDecimal faturado = dao.faturamento(LocalDate.now(), LocalDate.now());
        assertTrue(faturado.compareTo(new BigDecimal("180.00")) >= 0);
    }

    @Test
    void pesquisaPorStatusNumeroETexto() {
        assertTrue(dao.pesquisar(StatusOS.ABERTA, false, "MarcaTesteXYZ").contains(os));
        assertTrue(dao.pesquisar(null, false, String.valueOf(os.getId())).contains(os));
        assertTrue(dao.pesquisar(null, true, "Cliente OS Teste").contains(os));
        assertTrue(dao.pesquisar(StatusOS.ENTREGUE, false, "MarcaTesteXYZ").isEmpty());
    }

    @Test
    void contaPorStatusIncluiTodosOsStatus() {
        Map<StatusOS, Integer> contagem = dao.contarPorStatus();
        assertEquals(StatusOS.values().length, contagem.size());
        assertTrue(contagem.get(StatusOS.ABERTA) >= 1);
    }

    @Test
    void listaAtrasadas() {
        os.setDataPrevisao(LocalDate.now().minusDays(1));
        dao.alterar(os);
        assertTrue(dao.listarAtrasadas(LocalDate.now()).contains(os));
    }

    @Test
    void equipamentoComOsNaoPodeSerExcluido() {
        DAOException erro = assertThrows(DAOException.class, () -> equipamentoDAO.remover(equipamento.getId()));
        assertTrue(erro.getMessage().contains("ordens de serviço"));
    }

    private void avancar(StatusOS novo) {
        StatusOS anterior = os.getStatus();
        service.mudarStatus(os, novo, LocalDateTime.now().withNano(0));
        dao.registrarMudancaStatus(os, anterior, admin, null);
    }
}
