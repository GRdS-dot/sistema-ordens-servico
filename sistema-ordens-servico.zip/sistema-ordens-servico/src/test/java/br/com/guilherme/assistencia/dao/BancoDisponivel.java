package br.com.guilherme.assistencia.dao;

import static org.junit.jupiter.api.Assumptions.assumeTrue;

/**
 * Os testes de DAO precisam de um MySQL com o schema.sql aplicado.
 * Eles so rodam quando a variavel de ambiente DB_URL esta definida
 * (como no GitHub Actions). Sem ela, sao ignorados em vez de falhar.
 */
final class BancoDisponivel {

    private BancoDisponivel() {
    }

    static void exigir() {
        assumeTrue(System.getenv("DB_URL") != null,
                "DB_URL não definida: testes de banco ignorados");
    }
}
