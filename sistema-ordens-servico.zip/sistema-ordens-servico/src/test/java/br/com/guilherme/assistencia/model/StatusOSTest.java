package br.com.guilherme.assistencia.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StatusOSTest {

    @Test
    void fluxoNormalDeUmaOrdemDeServico() {
        assertTrue(StatusOS.ABERTA.podeMudarPara(StatusOS.EM_ANALISE));
        assertTrue(StatusOS.EM_ANALISE.podeMudarPara(StatusOS.AGUARDANDO_APROVACAO));
        assertTrue(StatusOS.AGUARDANDO_APROVACAO.podeMudarPara(StatusOS.EM_REPARO));
        assertTrue(StatusOS.EM_REPARO.podeMudarPara(StatusOS.PRONTA));
        assertTrue(StatusOS.PRONTA.podeMudarPara(StatusOS.ENTREGUE));
    }

    @Test
    void reparoPodePararParaEsperarPecaEVoltar() {
        assertTrue(StatusOS.EM_REPARO.podeMudarPara(StatusOS.AGUARDANDO_PECA));
        assertTrue(StatusOS.AGUARDANDO_PECA.podeMudarPara(StatusOS.EM_REPARO));
    }

    @Test
    void naoPermitePularEtapas() {
        assertFalse(StatusOS.ABERTA.podeMudarPara(StatusOS.PRONTA));
        assertFalse(StatusOS.EM_ANALISE.podeMudarPara(StatusOS.ENTREGUE));
        assertFalse(StatusOS.AGUARDANDO_PECA.podeMudarPara(StatusOS.PRONTA));
    }

    @Test
    void depoisQueOReparoComecaNaoPodeMaisCancelar() {
        assertTrue(StatusOS.AGUARDANDO_APROVACAO.podeMudarPara(StatusOS.CANCELADA));
        assertFalse(StatusOS.EM_REPARO.podeMudarPara(StatusOS.CANCELADA));
        assertFalse(StatusOS.PRONTA.podeMudarPara(StatusOS.CANCELADA));
    }

    @ParameterizedTest
    @EnumSource(value = StatusOS.class, names = {"ENTREGUE", "CANCELADA"})
    void statusFinaisNaoMudamMais(StatusOS status) {
        assertTrue(status.isFinal());
        assertTrue(status.proximosStatus().isEmpty());
    }

    @Test
    void naoAceitaStatusNulo() {
        assertFalse(StatusOS.ABERTA.podeMudarPara(null));
    }

    @Test
    void classeCssUsadaNasTelas() {
        assertEquals("status-aguardando-peca", StatusOS.AGUARDANDO_PECA.getClasseCss());
    }
}
